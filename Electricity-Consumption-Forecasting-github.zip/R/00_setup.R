# 00_setup.R — install packages and create folders
# Run once in RStudio: source("R/00_setup.R") from the project root
#                or     source("00_setup.R") from the R/ folder

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()

core <- c(
  "data.table", "dplyr", "tidyr", "lubridate", "ggplot2", "readr",
  "zoo", "imputeTS", "janitor", "scales", "viridis", "patchwork",
  "forecast", "tseries", "xgboost", "ranger", "rpart", "nnet",
  "changepoint", "cluster", "plotly", "DT", "shiny", "shinydashboard",
  "shinyWidgets", "knitr", "rmarkdown", "htmltools"
)
optional <- c(
  "prophet", "tsibble", "feasts", "fable", "fabletools", "timetk",
  "modeltime", "tidymodels", "anomalize", "tibbletime", "corrplot",
  "factoextra", "mgcv", "e1071", "padr", "mixvlmc", "calendR"
)

need <- core[!vapply(core, requireNamespace, logical(1), quietly = TRUE)]
if (length(need)) {
  cat("Installing core packages:\n")
  print(need)
  install.packages(need, dependencies = TRUE)
}

miss_opt <- optional[!vapply(optional, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss_opt)) {
  cat("\nOptional packages not installed (scripts degrade gracefully):\n")
  print(miss_opt)
  cat("To install: install.packages(c(",
      paste(sprintf('\"%s\"', miss_opt), collapse = ", "), "))\n", sep = "")
}

cat("\nProject root:", PROJECT_ROOT, "\n")
cat("Folders ready. Next: source 00_download.R (if needed), then 01_load.R ... 09_cost.R\n")
cat("Or run everything with source('R/10_run_all.R') from the project root.\n")
