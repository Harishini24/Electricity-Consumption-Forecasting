# 04_eda.R — analytics half: profiles, heatmaps, decomposition, KPIs

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(lubridate)
  library(tidyr)
})

message_header("04  Exploratory data analysis")
feat_path <- file.path(PATHS$processed, "df_features.rds")
if (!file.exists(feat_path)) stop("Run 03_features.R first.")
df <- readRDS(feat_path) %>% filter(!is.na(Global_active_power))
daily <- if (file.exists(file.path(PATHS$processed, "df_daily_features.rds"))) {
  readRDS(file.path(PATHS$processed, "df_daily_features.rds"))
} else NULL

theme_set(theme_minimal(base_size = 12))

# Descriptive KPI table
desc <- df %>%
  summarise(
    n_hours = n(),
    mean_kW = mean(Global_active_power, na.rm = TRUE),
    median_kW = median(Global_active_power, na.rm = TRUE),
    sd_kW = sd(Global_active_power, na.rm = TRUE),
    min_kW = min(Global_active_power, na.rm = TRUE),
    max_kW = max(Global_active_power, na.rm = TRUE),
    total_kWh = sum(kWh, na.rm = TRUE),
    peak_time = as.character(Datetime[which.max(Global_active_power)]),
    load_factor = mean_kW / max_kW
  )
write_table(desc, "descriptive_stats.csv")
cat("Load factor (avg/peak) =", round(desc$load_factor, 3), "\n")

# 1. Full daily series with trend
if (!is.null(daily)) {
  p <- ggplot(daily, aes(Datetime, kWh)) +
    geom_line(colour = "#3B6D91", alpha = 0.7) +
    geom_smooth(method = "loess", span = 0.08, se = FALSE, colour = "#C44E52", linewidth = 0.8) +
    labs(title = "Daily household energy (Sceaux, 2006-2010)",
         subtitle = "UCI Individual Household Electric Power Consumption",
         x = "Date", y = "kWh / day")
  safe_ggsave("01_daily_series.png", p, 10, 4)
}

# 2-3. STL on daily kWh
if (!is.null(daily) && requireNamespace("forecast", quietly = TRUE)) {
  y <- ts(daily$kWh, frequency = 7)
  stl_fit <- try(stl(y, s.window = "periodic"), silent = TRUE)
  if (!inherits(stl_fit, "try-error")) {
    png(file.path(PATHS$figures, "02_stl_weekly.png"), width = 1000, height = 700)
    plot(stl_fit, main = "STL decomposition of daily kWh (weekly seasonality)")
    dev.off()
  }
  y365 <- ts(daily$kWh, frequency = 365)
  stl_y <- try(stl(y365, s.window = "periodic", na.action = na.omit), silent = TRUE)
  if (!inherits(stl_y, "try-error")) {
    png(file.path(PATHS$figures, "03_stl_yearly.png"), width = 1000, height = 700)
    plot(stl_y, main = "STL decomposition of daily kWh (yearly seasonality)")
    dev.off()
  }
}

# 4. Average daily load curve with ribbon
prof <- df %>%
  group_by(hour) %>%
  summarise(mean_kw = mean(Global_active_power, na.rm = TRUE),
            lo = quantile(Global_active_power, 0.25, na.rm = TRUE),
            hi = quantile(Global_active_power, 0.75, na.rm = TRUE),
            .groups = "drop")
p <- ggplot(prof, aes(hour, mean_kw)) +
  geom_ribbon(aes(ymin = lo, ymax = hi), fill = "#3B6D91", alpha = 0.2) +
  geom_line(colour = "#3B6D91", linewidth = 1) +
  labs(title = "Average daily load profile (mean with IQR ribbon)",
       x = "Hour of day", y = "Active power (kW)")
safe_ggsave("04_daily_profile.png", p, 7, 4)

# 5. Weekday vs weekend
wd <- df %>%
  group_by(hour, is_weekend) %>%
  summarise(mean_kw = mean(Global_active_power, na.rm = TRUE), .groups = "drop") %>%
  mutate(day_type = ifelse(is_weekend == 1, "Weekend", "Weekday"))
p <- ggplot(wd, aes(hour, mean_kw, colour = day_type)) +
  geom_line(linewidth = 1) +
  scale_colour_manual(values = c(Weekday = "#3B6D91", Weekend = "#C44E52")) +
  labs(title = "Weekday vs weekend load profile", x = "Hour of day", y = "kW", colour = NULL)
safe_ggsave("05_weekday_weekend.png", p, 7, 4)

# 6. Hour x month heatmap
hm <- df %>%
  group_by(month, hour) %>%
  summarise(mean_kw = mean(Global_active_power, na.rm = TRUE), .groups = "drop")
p <- ggplot(hm, aes(hour, month, fill = mean_kw)) +
  geom_tile() +
  scale_fill_viridis_c(option = "plasma") +
  labs(title = "Consumption heatmap: hour of day vs month",
       x = "Hour of day", y = "Month", fill = "kW")
safe_ggsave("06_hour_month_heatmap.png", p, 8, 5)

# 7. Calendar-style daily heatmap
if (!is.null(daily)) {
  cal <- daily %>%
    mutate(Date = as.Date(Datetime), wday = wday(Date, label = TRUE, week_start = 1),
           week = isoweek(Date), year = year(Date))
  p <- ggplot(cal, aes(week, wday, fill = kWh)) +
    geom_tile(colour = "white") +
    scale_fill_viridis_c(option = "magma") +
    facet_wrap(~year, ncol = 1) +
    labs(title = "Calendar heatmap of daily kWh", x = "ISO week", y = NULL, fill = "kWh")
  safe_ggsave("07_calendar_heatmap.png", p, 10, 8)
}

# 8. Boxplots
p <- df %>%
  ggplot(aes(factor(hour), Global_active_power)) +
  geom_boxplot(outlier.alpha = 0.05, fill = "#3B6D91", colour = "#1F3A4D") +
  labs(title = "Hourly power distribution", x = "Hour", y = "kW")
safe_ggsave("08_box_hour.png", p, 9, 4)

p <- df %>%
  ggplot(aes(day_of_week, Global_active_power)) +
  geom_boxplot(outlier.alpha = 0.05, fill = "#6B8F71") +
  labs(title = "Power by weekday", x = NULL, y = "kW")
safe_ggsave("09_box_weekday.png", p, 7, 4)

p <- df %>%
  ggplot(aes(month, Global_active_power)) +
  geom_boxplot(outlier.alpha = 0.05, fill = "#C4A35A") +
  labs(title = "Power by month", x = NULL, y = "kW")
safe_ggsave("10_box_month.png", p, 8, 4)

# 9. ACF/PACF daily
if (!is.null(daily) && requireNamespace("forecast", quietly = TRUE)) {
  png(file.path(PATHS$figures, "11_acf_pacf_daily.png"), width = 1000, height = 450)
  par(mfrow = c(1, 2))
  acf(daily$kWh, lag.max = 40, na.action = na.pass, main = "ACF daily kWh")
  pacf(daily$kWh, lag.max = 40, na.action = na.pass, main = "PACF daily kWh")
  dev.off()
}

# 10. Stationarity tests
if (!is.null(daily) && requireNamespace("tseries", quietly = TRUE)) {
  x <- na.omit(daily$kWh)
  adf <- try(tseries::adf.test(x), silent = TRUE)
  kpss <- try(tseries::kpss.test(x), silent = TRUE)
  tests <- data.frame(
    test = c("ADF", "KPSS"),
    statistic = c(if (!inherits(adf, "try-error")) unname(adf$statistic) else NA,
                  if (!inherits(kpss, "try-error")) unname(kpss$statistic) else NA),
    p_value = c(if (!inherits(adf, "try-error")) adf$p.value else NA,
                if (!inherits(kpss, "try-error")) kpss$p.value else NA),
    interpretation = c(
      "Reject unit root (stationary) if p < 0.05",
      "Reject stationarity if p < 0.05"
    )
  )
  write_table(tests, "stationarity_tests.csv")
  print(tests)
}

# 11. Correlation heatmap of numeric sensor columns
num <- df %>%
  select(Global_active_power, Global_reactive_power, Voltage, Global_intensity,
         Sub_metering_1, Sub_metering_2, Sub_metering_3, Rest_of_house, temperature_c, CDD, HDD) %>%
  cor(use = "pairwise.complete.obs")
write_table(as.data.frame(num), "correlation_matrix.csv")
cm <- as.data.frame(as.table(num))
names(cm) <- c("x", "y", "corr")
p <- ggplot(cm, aes(x, y, fill = corr)) +
  geom_tile() +
  scale_fill_gradient2(low = "#3B6D91", mid = "white", high = "#C44E52", midpoint = 0) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Correlation of sensors, weather and sub-meters", x = NULL, y = NULL, fill = "r")
safe_ggsave("12_correlation.png", p, 8, 7)

# 12. Temperature vs load
p <- df %>%
  sample_n(min(8000, n())) %>%
  ggplot(aes(temperature_c, Global_active_power)) +
  geom_point(alpha = 0.15, colour = "#3B6D91") +
  geom_smooth(method = "loess", se = FALSE, colour = "#C44E52") +
  labs(title = "Temperature vs hourly load (Sceaux)",
       subtitle = "U-shape / hockey-stick: heating at low T, mild cooling at high T",
       x = "Outdoor temperature (C)", y = "kW")
safe_ggsave("13_temp_vs_load.png", p, 7, 4.5)

# 13. Sub-meter stacked (daily means by hour of a typical year)
sm <- df %>%
  filter(year == 2008) %>%
  group_by(hour) %>%
  summarise(
    Kitchen = mean(Sub_metering_1, na.rm = TRUE),
    Laundry = mean(Sub_metering_2, na.rm = TRUE),
    WaterHeater_AC = mean(Sub_metering_3, na.rm = TRUE),
    Rest = mean(Rest_of_house, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_longer(-hour, names_to = "end_use", values_to = "Wh")
p <- ggplot(sm, aes(hour, Wh, fill = end_use)) +
  geom_area(alpha = 0.9) +
  scale_fill_manual(values = c(Kitchen = "#C44E52", Laundry = "#C4A35A",
                               WaterHeater_AC = "#3B6D91", Rest = "#6B8F71")) +
  labs(title = "Average hourly sub-meter energy (2008)", x = "Hour", y = "Wh (hourly sum)", fill = "End use")
safe_ggsave("14_submeter_stacked.png", p, 8, 4.5)

share <- df %>%
  summarise(Kitchen = sum(Sub_metering_1, na.rm = TRUE),
            Laundry = sum(Sub_metering_2, na.rm = TRUE),
            WaterHeater_AC = sum(Sub_metering_3, na.rm = TRUE),
            Rest = sum(Rest_of_house, na.rm = TRUE)) %>%
  pivot_longer(everything(), names_to = "end_use", values_to = "Wh") %>%
  mutate(pct = 100 * Wh / sum(Wh))
write_table(share, "appliance_share.csv")
p <- ggplot(share, aes(x = "", y = pct, fill = end_use)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Share of measured energy by end-use", x = NULL, y = NULL, fill = NULL)
safe_ggsave("15_appliance_share.png", p, 6, 5)

# 14. Base vs peak
bp <- df %>%
  mutate(Date = as.Date(Datetime)) %>%
  group_by(Date) %>%
  summarise(base_load = min(Global_active_power, na.rm = TRUE),
            peak_load = max(Global_active_power, na.rm = TRUE),
            avg_load = mean(Global_active_power, na.rm = TRUE),
            .groups = "drop")
write_table(head(bp, 20), "base_peak_sample.csv")
p <- bp %>%
  mutate(year = year(Date)) %>%
  group_by(year) %>%
  summarise(mean_base = mean(base_load), mean_peak = mean(peak_load), .groups = "drop") %>%
  pivot_longer(-year) %>%
  ggplot(aes(factor(year), value, fill = name)) +
  geom_col(position = "dodge") +
  labs(title = "Mean daily base load vs peak load by year", x = "Year", y = "kW", fill = NULL)
safe_ggsave("16_base_vs_peak.png", p, 7, 4)

# 15. Peak demand clock
peak_hour_tbl <- df %>%
  mutate(Date = as.Date(Datetime)) %>%
  group_by(Date) %>%
  slice_max(Global_active_power, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  count(hour, name = "n_peak_days")
p <- ggplot(peak_hour_tbl, aes(hour, n_peak_days)) +
  geom_col(fill = "#C44E52") +
  labs(title = "When does the daily peak occur?", x = "Hour of daily maximum", y = "Number of days")
safe_ggsave("17_peak_hour_hist.png", p, 7, 4)

# 16. YoY / MoM
if (!is.null(daily)) {
  mom <- daily %>%
    mutate(YearMonth = floor_date(Datetime, "month")) %>%
    group_by(YearMonth) %>%
    summarise(kWh = sum(kWh, na.rm = TRUE), .groups = "drop") %>%
    mutate(mom_pct = 100 * (kWh / lag(kWh) - 1),
           yoy_pct = 100 * (kWh / lag(kWh, 12) - 1))
  write_table(mom, "yoy_mom_kwh.csv")
}

# Evening peak driver
eve <- df %>%
  filter(hour >= 18, hour < 22) %>%
  summarise(Kitchen = mean(Sub_metering_1, na.rm = TRUE),
            Laundry = mean(Sub_metering_2, na.rm = TRUE),
            WaterHeater_AC = mean(Sub_metering_3, na.rm = TRUE),
            Rest = mean(Rest_of_house, na.rm = TRUE))
write_table(eve, "evening_peak_enduse.csv")
cat("EDA figures written to outputs/figures/\n")
