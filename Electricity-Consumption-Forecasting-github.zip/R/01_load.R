# 01_load.R — ingestion, datetime parse, missing-value report

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(lubridate)
})

message_header("01  Data ingestion & quality")

file_path <- raw_txt_path()
if (!file.exists(file_path)) {
  stop("Dataset not found at ", file_path,
       "\nRun R/00_download.R or place household_power_consumption.txt in data/raw/.\n",
       "Direct zip: https://archive.ics.uci.edu/static/public/235/individual+household+electric+power+consumption.zip")
}

df_raw <- fread(file_path, sep = ";", na.strings = c("?", "NA", ""), showProgress = TRUE)

# Self-check against the published UCI card
expected_rows <- 2075259L
cat(sprintf("Rows read: %s (UCI published n = %s)\n", format(nrow(df_raw), big.mark = ","), format(expected_rows, big.mark = ",")))
if (nrow(df_raw) != expected_rows) {
  warning("Row count differs from the UCI documentation. Check that the full file was unzipped.")
}

df_raw[, Datetime := dmy_hms(paste(Date, Time), tz = "Europe/Paris")]
df_raw[, Date := NULL]
df_raw[, Time := NULL]
setcolorder(df_raw, "Datetime")
setkey(df_raw, Datetime)

n_dup <- sum(duplicated(df_raw$Datetime))
if (n_dup > 0) {
  cat(sprintf("Removing %d duplicate timestamps (keep first).\n", n_dup))
  df_raw <- df_raw[!duplicated(Datetime)]
}

# DST: Europe/Paris POSIXct already encodes the autumn overlap; flag duplicated clock times
dst_flag <- duplicated(format(df_raw$Datetime, "%Y-%m-%d %H:%M:%S"))

miss <- sapply(df_raw, function(x) sum(is.na(x)))
miss_tbl <- data.frame(
  column = names(miss),
  missing_count = as.integer(miss),
  missing_pct = round(100 * miss / nrow(df_raw), 4),
  stringsAsFactors = FALSE
)

target_na <- is.na(df_raw$Global_active_power)
r <- rle(target_na)
gap_lengths <- r$lengths[r$values]
n_gaps <- length(gap_lengths)
longest_gap <- if (n_gaps) max(gap_lengths) else 0L

# Locate longest gap
gap_start <- gap_end <- as.POSIXct(NA, tz = "Europe/Paris")
if (n_gaps) {
  end_idx <- cumsum(r$lengths)
  start_idx <- end_idx - r$lengths + 1
  i <- which(r$values & r$lengths == longest_gap)[1]
  gap_start <- df_raw$Datetime[start_idx[i]]
  gap_end   <- df_raw$Datetime[end_idx[i]]
}

quality <- data.frame(
  metric = c(
    "n_rows", "n_cols", "start", "end",
    "missing_target", "missing_target_pct",
    "n_gap_periods", "longest_gap_minutes", "longest_gap_hours",
    "longest_gap_start", "longest_gap_end",
    "duplicate_timestamps", "negative_power",
    "quality_score_0_100"
  ),
  value = c(
    nrow(df_raw), ncol(df_raw),
    as.character(min(df_raw$Datetime, na.rm = TRUE)),
    as.character(max(df_raw$Datetime, na.rm = TRUE)),
    miss_tbl$missing_count[miss_tbl$column == "Global_active_power"],
    miss_tbl$missing_pct[miss_tbl$column == "Global_active_power"],
    n_gaps, longest_gap, round(longest_gap / 60, 2),
    as.character(gap_start), as.character(gap_end),
    n_dup,
    sum(df_raw$Global_active_power < 0, na.rm = TRUE),
    round(100 - miss_tbl$missing_pct[miss_tbl$column == "Global_active_power"] -
            pmin(5, longest_gap / (24 * 60)), 2)
  ),
  stringsAsFactors = FALSE
)

cat("\nMissing value report:\n")
print(miss_tbl)
cat("\nQuality summary (self-check targets: n=2,075,259; missing=25,979 / 1.25%; longest gap ~120 h from 2010-08-17):\n")
print(quality)

write_table(miss_tbl, "missing_value_report.csv")
write_table(quality, "data_quality_summary.csv")

saveRDS(df_raw, file.path(PATHS$processed, "df_loaded.rds"))
cat("\nSaved data/processed/df_loaded.rds\n")
