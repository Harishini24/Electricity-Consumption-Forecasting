# 00_download.R
# Fetch UCI household power zip (id=235) and Open-Meteo Sceaux weather.
# mixvlmc::powerconsumption is an optional 2008 10-minute fallback.

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()

UCI_ZIP <- "https://archive.ics.uci.edu/static/public/235/individual+household+electric+power+consumption.zip"
UCI_PAGE <- "https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption"
dest_txt <- raw_txt_path()
dest_zip <- file.path(PATHS$raw, "household_power_consumption.zip")

download_uci <- function() {
  if (file.exists(dest_txt) && file.info(dest_txt)$size > 1e8) {
    cat(sprintf("UCI file already present (%.1f MB). Skipping download.\n",
                file.info(dest_txt)$size / 1e6))
    return(invisible(TRUE))
  }
  cat("Downloading UCI Individual Household Electric Power Consumption...\n")
  cat("URL:", UCI_ZIP, "\n")
  ok <- tryCatch({
    utils::download.file(UCI_ZIP, dest_zip, mode = "wb", quiet = FALSE)
    TRUE
  }, error = function(e) {
    message("Direct zip failed: ", e$message)
    FALSE
  })
  if (!ok || !file.exists(dest_zip) || file.info(dest_zip)$size < 1e6) {
    stop("Download failed. Open ", UCI_PAGE, " and use the Download button, then unzip household_power_consumption.txt into data/raw/.")
  }
  utils::unzip(dest_zip, exdir = PATHS$raw)
  if (!file.exists(dest_txt)) {
    # some zips nest the txt
    found <- list.files(PATHS$raw, pattern = "household_power_consumption\\.txt$", recursive = TRUE, full.names = TRUE)
    if (length(found)) file.copy(found[1], dest_txt, overwrite = TRUE)
  }
  if (!file.exists(dest_txt)) stop("Zip downloaded but txt not found after unzip.")
  cat(sprintf("Saved %s (%.1f MB)\n", dest_txt, file.info(dest_txt)$size / 1e6))
  invisible(TRUE)
}

download_weather <- function() {
  weather_file <- file.path(PATHS$external, "weather_sceaux.csv")
  if (file.exists(weather_file) && file.info(weather_file)$size > 1e5) {
    cat("Weather file already present. Skipping Open-Meteo download.\n")
    return(invisible(TRUE))
  }
  url <- paste0(
    "https://archive-api.open-meteo.com/v1/archive?",
    "latitude=48.7767&longitude=2.2906",
    "&start_date=2006-12-16&end_date=2010-11-26",
    "&hourly=temperature_2m,relative_humidity_2m",
    "&timezone=Europe%2FParis"
  )
  cat("Downloading Sceaux/Paris hourly weather from Open-Meteo archive...\n")
  tmp <- tempfile(fileext = ".json")
  tryCatch({
    utils::download.file(url, tmp, mode = "wb", quiet = TRUE)
    raw <- paste(readLines(tmp, warn = FALSE), collapse = "")
    if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite")
    obj <- jsonlite::fromJSON(raw)
    wx <- data.frame(
      Datetime = obj$hourly$time,
      temperature_c = obj$hourly$temperature_2m,
      relative_humidity = obj$hourly$relative_humidity_2m,
      stringsAsFactors = FALSE
    )
    utils::write.csv(wx, weather_file, row.names = FALSE)
    cat(sprintf("Wrote %d hourly weather rows to %s\n", nrow(wx), weather_file))
  }, error = function(e) {
    message("Open-Meteo download failed (", e$message, "). 03_features.R will use Paris climatology as fallback.")
  })
  invisible(TRUE)
}

save_mixvlmc_fallback <- function() {
  out <- file.path(PATHS$processed, "mixvlmc_powerconsumption_2008.rds")
  if (file.exists(out)) return(invisible(TRUE))
  if (!requireNamespace("mixvlmc", quietly = TRUE)) {
    cat("Optional CRAN package mixvlmc not installed. It contains a cleaned 2008 10-minute subset (52,704 rows) useful for script dry-runs.\n")
    cat("install.packages(\"mixvlmc\") then re-run 00_download.R if you want that fallback.\n")
    return(invisible(FALSE))
  }
  utils::data("powerconsumption", package = "mixvlmc", envir = environment())
  saveRDS(powerconsumption, out)
  cat("Saved mixvlmc::powerconsumption (2008 10-min subset) to data/processed/.\n")
  invisible(TRUE)
}

download_uci()
download_weather()
save_mixvlmc_fallback()
cat("Download step complete.\n")
