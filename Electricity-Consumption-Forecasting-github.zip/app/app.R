# app.R
# Shiny Dashboard for Smart Energy Intelligence System

library(shiny)
library(shinydashboard)
library(dplyr)
library(ggplot2)

ui <- dashboardPage(
  dashboardHeader(title = "Energy Analytics Using R", titleWidth = 300),
  dashboardSidebar(
    width = 300,
    sidebarMenu(
      menuItem("1. Predictive Intelligence", tabName = "predictive", icon = icon("chart-line")),
      menuItem("2. Diagnostic Intelligence", tabName = "diagnostic", icon = icon("search")),
      menuItem("3. Prescriptive (Simulator)", tabName = "prescriptive", icon = icon("sliders-h"))
    )
  ),
  dashboardBody(
    tabItems(
      # Layer 1
      tabItem(tabName = "predictive",
              fluidRow(
                valueBox("38.4 kWh", "Next 24h Forecast", icon = icon("bolt"), color = "yellow"),
                valueBox("HIGH (83%)", "Peak Demand Risk", icon = icon("exclamation-triangle"), color = "red"),
                valueBox("94.2%", "XGBoost Accuracy", icon = icon("check-circle"), color = "green")
              ),
              fluidRow(
                box(title = "Multi-Horizon Load Forecast", width = 12, plotOutput("forecastPlot"))
              )
      ),
      # Layer 2
      tabItem(tabName = "diagnostic",
              fluidRow(
                valueBox("3 Events", "Recent Anomalies", icon = icon("bell"), color = "red"),
                valueBox("HIGH", "Energy Waste Index", icon = icon("trash"), color = "orange")
              ),
              fluidRow(
                box(title = "SHAP Feature Importance (Explainable AI)", width = 12, plotOutput("shapPlot"))
              )
      ),
      # Layer 3
      tabItem(tabName = "prescriptive",
              fluidRow(
                box(title = "What-If Optimization Simulator", width = 12,
                    sliderInput("peak_reduction", "Reduce Peak Consumption (18:00 - 22:00) %:", min = 0, max = 30, value = 0),
                    sliderInput("shift_load", "Shift AC/Laundry Load to Off-Peak (kWh):", min = 0, max = 5, value = 0, step = 0.5),
                    hr(),
                    h3(textOutput("sim_bill")),
                    h4(textOutput("sim_carbon"), style = "color: green;")
                )
              )
      )
    )
  )
)

server <- function(input, output) {
  
  output$forecastPlot <- renderPlot({
    # Placeholder for actual ggplot forecast object
    df_dummy <- data.frame(Hour = 0:23, Load = sin(seq(0, pi, length.out = 24)) * 3 + 1)
    ggplot(df_dummy, aes(x = Hour, y = Load)) + geom_line(color = "red", size=1) + 
      theme_minimal() + labs(title = "Expected 24-Hour Load Profile")
  })
  
  output$shapPlot <- renderPlot({
    # Placeholder for SHAP plot
    df_shap <- data.frame(Feature = c("Temperature", "Lag_24h", "Hour=19", "Rolling Mean", "Weekend"),
                          Impact = c(0.72, 0.51, 0.42, 0.31, -0.18))
    ggplot(df_shap, aes(x = reorder(Feature, Impact), y = Impact, fill = Impact > 0)) +
      geom_bar(stat = "identity") + coord_flip() + theme_minimal() +
      labs(title = "Drivers of Demand", x = "Feature", y = "SHAP Value Impact")
  })
  
  output$sim_bill <- renderText({
    base_bill <- 1840
    savings <- (input$peak_reduction * 12) + (input$shift_load * 45)
    new_bill <- max(base_bill - savings, 600)
    paste("Optimized Estimated Monthly Bill: ₹", round(new_bill, 0))
  })
  
  output$sim_carbon <- renderText({
    savings <- (input$peak_reduction * 12) + (input$shift_load * 45)
    carbon_saved <- savings / 8
    paste("Carbon Emissions Saved:", round(carbon_saved, 1), "kg CO₂")
  })
}

shinyApp(ui, server)
