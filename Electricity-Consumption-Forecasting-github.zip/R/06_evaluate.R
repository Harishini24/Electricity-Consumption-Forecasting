# 06_evaluate.R — residual diagnostics, leaderboard plots, intervals

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
})

message_header("06  Evaluation & residual diagnostics")
cmp_path <- file.path(PATHS$tables, "model_comparison.csv")
if (!file.exists(cmp_path)) cmp_path <- file.path(PATHS$forecasts, "model_comparison.csv")
if (!file.exists(cmp_path)) stop("Run 05_models.R first.")

metrics <- read.csv(cmp_path, stringsAsFactors = FALSE)
fc <- read.csv(file.path(PATHS$forecasts, "forecast_all_models.csv"), stringsAsFactors = FALSE)
fc$Datetime <- as.POSIXct(fc$Datetime)

theme_set(theme_minimal())

p <- metrics %>%
  filter(grain == "hourly") %>%
  ggplot(aes(reorder(model, RMSE), RMSE)) +
  geom_col(fill = "#3B6D91") +
  coord_flip() +
  labs(title = "Hourly model leaderboard (RMSE, chronological holdout)",
       x = NULL, y = "RMSE (kW)")
safe_ggsave("18_model_rmse.png", p, 8, 4)

p <- metrics %>%
  filter(grain == "daily") %>%
  ggplot(aes(reorder(model, RMSE), RMSE)) +
  geom_col(fill = "#6B8F71") +
  coord_flip() +
  labs(title = "Daily 30-day holdout leaderboard (RMSE)", x = NULL, y = "RMSE (kWh/day)")
safe_ggsave("19_model_rmse_daily.png", p, 8, 4)

best <- metrics %>% filter(grain == "hourly") %>% slice_min(RMSE, n = 1)
best_fc <- fc %>% filter(model == best$model[1])

p <- ggplot(best_fc, aes(Datetime)) +
  geom_line(aes(y = actual, colour = "Actual"), linewidth = 0.6) +
  geom_line(aes(y = point_forecast, colour = "Forecast"), linewidth = 0.6) +
  scale_colour_manual(values = c(Actual = "#1F3A4D", Forecast = "#C44E52")) +
  labs(title = paste("Actual vs predicted —", best$model[1]),
       x = "Time", y = "kW", colour = NULL)
safe_ggsave("20_actual_vs_pred.png", p, 10, 4)

# Residual panel for best hourly
best_fc <- best_fc %>% mutate(resid = actual - point_forecast)
p <- ggplot(best_fc, aes(sample = resid)) +
  stat_qq() + stat_qq_line(colour = "#C44E52") +
  labs(title = paste("Residual Q-Q —", best$model[1]), x = "Theoretical", y = "Residual (kW)")
safe_ggsave("21_residual_qq.png", p, 5, 4)

if (requireNamespace("forecast", quietly = TRUE)) {
  png(file.path(PATHS$figures, "22_residual_acf.png"), width = 900, height = 400)
  acf(best_fc$resid, lag.max = 72, na.action = na.pass, main = paste("Residual ACF —", best$model[1]))
  dev.off()
}

lb <- Box.test(na.omit(best_fc$resid), lag = 48, type = "Ljung-Box",
               fitdf = ifelse(grepl("ARIMA", best$model[1], ignore.case = TRUE), 2, 0))
diag <- data.frame(
  model = best$model[1],
  ljung_box_statistic = unname(lb$statistic),
  ljung_box_df = unname(lb$parameter),
  ljung_box_p = lb$p.value,
  residual_mean = mean(best_fc$resid, na.rm = TRUE),
  residual_sd = sd(best_fc$resid, na.rm = TRUE)
)
write_table(diag, "residual_diagnostics.csv")
cat(sprintf("Ljung-Box p-value for %s: %.4f\n", best$model[1], lb$p.value))
cat("If p is small, residuals still contain serial correlation — typical for ML point forecasts without an AR residual layer.\n")
