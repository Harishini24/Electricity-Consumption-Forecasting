# 11_real_time_monitor.R
# Advanced Feature: Simulated Real-Time Smart Meter Monitoring
# This script simulates taking a live data stream and calculating rolling features in real-time.

library(dplyr)
library(lubridate)

cat("Starting Real-Time Monitor Simulation...\n")

# Simulate 100 live readings (e.g., from an MQTT stream or Kafka topic)
simulate_stream <- function(n = 100) {
  base_time <- Sys.time()
  
  stream_data <- data.frame(
    timestamp = base_time + seq(1, n) * 60, # 1 reading every minute
    active_power_kw = 2.0 + rnorm(n, mean = 0, sd = 0.5)
  )
  
  # Calculate real-time rolling features (e.g., trailing 5-minute moving average)
  stream_data <- stream_data %>%
    mutate(
      rolling_5min_avg = zoo::rollapply(active_power_kw, width = 5, FUN = mean, fill = NA, align = "right"),
      spike_alert = ifelse(active_power_kw > 3.5, TRUE, FALSE)
    )
  
  return(stream_data)
}

# Run simulation
live_feed <- simulate_stream(100)

cat("Simulated 100 minutes of live data.\n")
cat("Recent Spikes Detected:\n")
print(live_feed %>% filter(spike_alert == TRUE))

# In a production setting, this would write to a live dashboard or database.
cat("\nReal-time monitoring module ready. (See index.html for interactive visual simulation)\n")
