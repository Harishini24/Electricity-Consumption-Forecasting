# 08_cluster.R — cluster DAYS (24-hour shape), not consumers
# z-score each day so k-means groups shape; elbow + silhouette; interpret profiles.

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(lubridate)
})

message_header("08  Load-profile clustering")
path <- file.path(PATHS$processed, "df_features.rds")
if (!file.exists(path)) stop("Run 03_features.R first.")
df <- readRDS(path) %>% filter(!is.na(Global_active_power), !is.na(hour))

daily_profiles <- df %>%
  mutate(Date = as.Date(Datetime)) %>%
  select(Date, hour, Global_active_power, is_weekend, month_num, kWh) %>%
  group_by(Date, hour) %>%
  summarise(Global_active_power = mean(Global_active_power, na.rm = TRUE),
            is_weekend = max(is_weekend), month_num = max(month_num),
            .groups = "drop") %>%
  tidyr::pivot_wider(names_from = hour, values_from = Global_active_power, names_prefix = "H_") %>%
  drop_na()

daily_kwh <- df %>%
  mutate(Date = as.Date(Datetime)) %>%
  group_by(Date) %>%
  summarise(daily_kWh = sum(kWh, na.rm = TRUE), .groups = "drop")
daily_profiles <- daily_profiles %>% left_join(daily_kwh, by = "Date")

cat(sprintf("Complete days for clustering: %d\n", nrow(daily_profiles)))

hour_cols <- grep("^H_", names(daily_profiles), value = TRUE)
mat <- as.matrix(daily_profiles[, hour_cols])
# z-score each row (shape, not magnitude)
scaled <- t(apply(mat, 1, function(r) {
  s <- sd(r)
  if (is.na(s) || s == 0) r * 0 else as.numeric(scale(r))
}))

# Elbow for k = 2..8
set.seed(123)
ks <- 2:8
wss <- sapply(ks, function(k) kmeans(scaled, centers = k, nstart = 10, iter.max = 30)$tot.withinss)
elbow <- data.frame(k = ks, tot_withinss = wss)
write_table(elbow, "cluster_elbow.csv")
p <- ggplot(elbow, aes(k, tot_withinss)) +
  geom_line() + geom_point(size = 2) +
  labs(title = "k-means elbow on z-scored daily load shapes", x = "k", y = "Total within-cluster SS")
safe_ggsave("25_cluster_elbow.png", p, 6, 4)

k_use <- 3
km <- kmeans(scaled, centers = k_use, nstart = 25, iter.max = 50)
daily_profiles$cluster <- factor(km$cluster)

sil_mean <- NA
if (requireNamespace("cluster", quietly = TRUE)) {
  sil <- cluster::silhouette(km$cluster, dist(scaled))
  sil_mean <- mean(sil[, 3])
  cat(sprintf("Mean silhouette (k=%d): %.3f\n", k_use, sil_mean))
}

# Interpret: peak hour of cluster centroid (on original kW, not z)
long <- daily_profiles %>%
  select(Date, cluster, daily_kWh, is_weekend, month_num, starts_with("H_")) %>%
  pivot_longer(starts_with("H_"), names_to = "hour", values_to = "kW") %>%
  mutate(hour = as.integer(sub("H_", "", hour)))

cent <- long %>%
  group_by(cluster, hour) %>%
  summarise(kW = mean(kW), .groups = "drop")

p <- ggplot(long, aes(hour, kW, group = Date, colour = cluster)) +
  geom_line(alpha = 0.05) +
  geom_line(data = cent, aes(hour, kW, group = cluster), colour = "#1F3A4D", linewidth = 1.1) +
  facet_wrap(~cluster, nrow = 1) +
  guides(colour = "none") +
  labs(title = "Typical daily load shapes (k-means, k=3, z-scored days)",
       x = "Hour of day", y = "kW")
safe_ggsave("26_cluster_profiles.png", p, 10, 4)

summary <- long %>%
  group_by(cluster) %>%
  summarise(
    n_days = n_distinct(Date),
    mean_daily_kWh = mean(daily_kWh, na.rm = TRUE),
    pct_weekend = 100 * mean(is_weekend, na.rm = TRUE),
    peak_hour = hour[which.max(tapply(kW, hour, mean)[as.character(hour)])],
    .groups = "drop"
  )
# cleaner peak hour from centroids
peak <- cent %>% group_by(cluster) %>% slice_max(kW, n = 1, with_ties = FALSE) %>%
  transmute(cluster, peak_hour = hour, peak_kW = kW)
summary <- summary %>% select(-peak_hour) %>% left_join(peak, by = "cluster") %>%
  mutate(
    description = case_when(
      peak_hour >= 18 ~ "Evening-peak household (cooking / lighting / water heating)",
      peak_hour >= 11 & peak_hour <= 15 ~ "Midday-peak (laundry / occupancy)",
      TRUE ~ "Flat or night-biased (low occupancy / base load)"
    ),
    silhouette_mean = sil_mean
  )
write_table(summary, "cluster_summary.csv")
print(summary)

saveRDS(daily_profiles, file.path(PATHS$processed, "df_day_clusters.rds"))
cat("Clustering complete. Saved cluster_summary.csv\n")
