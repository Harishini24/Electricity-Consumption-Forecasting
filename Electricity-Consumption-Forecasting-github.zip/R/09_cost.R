# 09_cost.R — TANGEDCO LT-IA bill, CO2, ToD shift, solar overlay, what-if +2C

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(lubridate)
  library(ggplot2)
  library(tidyr)
})

message_header("09  Cost, carbon, solar, load-shift")
# DISCLAIMER: meter data is a Sceaux (France) household, 2006-2010.
# Tariff + CEA emission factor are Indian overlays to make the module reusable
# on TANGEDCO / TNPDCL meter exports.

h_path <- file.path(PATHS$processed, "df_features.rds")
if (!file.exists(h_path)) stop("Run 03_features.R first.")
df <- readRDS(h_path) %>% filter(!is.na(kWh))

monthly <- df %>%
  mutate(YearMonth = floor_date(Datetime, "month")) %>%
  group_by(YearMonth) %>%
  summarise(
    Total_kWh = sum(kWh, na.rm = TRUE),
    Peak_kW = max(Global_active_power, na.rm = TRUE),
    Avg_kW = mean(Global_active_power, na.rm = TRUE),
    peak_kWh = sum(kWh[tariff_slot == "Peak"], na.rm = TRUE),
    offpeak_kWh = sum(kWh[tariff_slot == "OffPeak"], na.rm = TRUE),
    kitchen_kWh = sum(Sub_metering_1, na.rm = TRUE) / 1000,
    laundry_kWh = sum(Sub_metering_2, na.rm = TRUE) / 1000,
    water_ac_kWh = sum(Sub_metering_3, na.rm = TRUE) / 1000,
    rest_kWh = sum(Rest_of_house, na.rm = TRUE) / 1000,
    .groups = "drop"
  ) %>%
  mutate(
    # Convert monthly kWh to a synthetic bi-monthly volume (x2) then half the bill
    bimonthly_units = Total_kWh * 2,
    Estimated_Bill_INR = tangedco_bill_bimonthly(bimonthly_units) / 2,
    CO2_kg = Total_kWh * CO2_KG_PER_KWH,
    load_factor = Avg_kW / Peak_kW
  )

# Next-month bill range: last 3 months mean +/- 1 SD, run through tariff
recent <- tail(monthly, 3)
mu <- mean(recent$Total_kWh); sdv <- sd(recent$Total_kWh)
if (is.na(sdv) || sdv == 0) sdv <- 0.1 * mu
fc_kwh <- c(mu - sdv, mu, mu + sdv)
fc_bill <- tangedco_bill_bimonthly(fc_kwh * 2) / 2
forecast_bill <- data.frame(
  scenario = c("lo_1sd", "point", "hi_1sd"),
  kWh = fc_kwh,
  bill_INR = fc_bill,
  CO2_kg = fc_kwh * CO2_KG_PER_KWH
)

write_table(monthly, "monthly_cost_emissions.csv")
write_table(forecast_bill, "next_month_bill_range.csv")

# Top 10 most expensive days
days <- df %>%
  mutate(Date = as.Date(Datetime)) %>%
  group_by(Date) %>%
  summarise(kWh = sum(kWh, na.rm = TRUE),
            peak_share = sum(kWh[tariff_slot == "Peak"], na.rm = TRUE),
            .groups = "drop") %>%
  mutate(illustrative_cost = tangedco_bill_bimonthly(kWh * 60) / 30) %>% # rough daily slice of a 2-month 30d*2 bill
  arrange(desc(kWh))
write_table(head(days, 10), "top10_expensive_days.csv")

# Load-shift simulator: move X% of peak kWh into off-peak
shift_pct <- c(0.1, 0.2, 0.3)
shift_tbl <- lapply(shift_pct, function(p) {
  peak <- sum(df$kWh[df$tariff_slot == "Peak"], na.rm = TRUE)
  off  <- sum(df$kWh[df$tariff_slot == "OffPeak"], na.rm = TRUE)
  moved <- p * peak
  # ToD overlay: peak * 1.25, off-peak * 0.95 vs flat energy charge
  flat_rate <- 8  # illustrative Rs/kWh around mid slab
  cost_now <- 1.25 * flat_rate * peak + 0.95 * flat_rate * off +
    flat_rate * (sum(df$kWh, na.rm = TRUE) - peak - off)
  cost_new <- 1.25 * flat_rate * (peak - moved) + 0.95 * flat_rate * (off + moved) +
    flat_rate * (sum(df$kWh, na.rm = TRUE) - peak - off)
  data.frame(shift_pct = 100 * p, kWh_moved = moved, savings_INR = cost_now - cost_new)
}) %>% bind_rows()
write_table(shift_tbl, "load_shift_savings.csv")

# Solar rooftop overlay (3 kWp, simple clear-sky diurnal)
pv_kwp <- 3
df_pv <- df %>%
  mutate(
    daylight = pmax(sin(pi * (hour - 6) / 12), 0),
    season_cf = 0.14 + 0.06 * sin(2 * pi * (yday - 172) / 365.25),
    pv_kW = pv_kwp * daylight * (season_cf / 0.18) * 0.5,
    pv_kWh = pv_kW, # hourly
    self_kWh = pmin(kWh, pv_kWh),
    export_kWh = pmax(pv_kWh - kWh, 0),
    grid_kWh = pmax(kWh - pv_kWh, 0)
  )
pv_sum <- df_pv %>%
  summarise(
    years = as.numeric(difftime(max(Datetime), min(Datetime), units = "days")) / 365.25,
    load_kWh = sum(kWh, na.rm = TRUE),
    pv_kWh = sum(pv_kWh, na.rm = TRUE),
    self_kWh = sum(self_kWh, na.rm = TRUE),
    export_kWh = sum(export_kWh, na.rm = TRUE),
    self_consumption_pct = 100 * self_kWh / pmax(pv_kWh, 1)
  ) %>%
  mutate(
    capex_INR = pv_kwp * 55000,
    annual_self_kWh = self_kWh / years,
    annual_savings_INR = annual_self_kWh * 8,
    simple_payback_years = capex_INR / pmax(annual_savings_INR, 1)
  )
write_table(pv_sum, "solar_feasibility.csv")

# What-if +2 C: degree-day regression on daily kWh
daily <- readRDS(file.path(PATHS$processed, "df_daily_features.rds"))
dd <- daily %>% filter(is.finite(kWh), is.finite(CDD), is.finite(HDD), is.finite(temperature_c))
fit_dd <- lm(kWh ~ CDD + HDD, data = dd)
dd2 <- dd %>% mutate(temperature_c = temperature_c + 2,
                     CDD = pmax(temperature_c - 18, 0) * 24, # already daily sums in features
                     HDD = pmax(18 - temperature_c, 0) * 24)
# daily CDD in 03 is sum of hourly CDD already — just shift temperature then rebuild
dd_shift <- daily %>%
  filter(is.finite(kWh), is.finite(temperature_c)) %>%
  mutate(temp2 = temperature_c + 2,
         CDD2 = pmax(temp2 - 18, 0) * 24,
         HDD2 = pmax(18 - temp2, 0) * 24)
fit_sig <- lm(kWh ~ I(pmax(temperature_c - 18, 0)) + I(pmax(18 - temperature_c, 0)), data = dd)
pred0 <- predict(fit_sig, dd)
pred2 <- predict(fit_sig, mutate(dd, temperature_c = temperature_c + 2))
whatif <- data.frame(
  mean_kWh_now = mean(pred0, na.rm = TRUE),
  mean_kWh_plus2C = mean(pred2, na.rm = TRUE),
  pct_change = 100 * (mean(pred2, na.rm = TRUE) / mean(pred0, na.rm = TRUE) - 1),
  r2 = summary(fit_sig)$r.squared
)
write_table(whatif, "whatif_plus2C.csv")

# Automated text insight
last2 <- tail(monthly, 2)
insight <- if (nrow(last2) == 2) {
  chg <- 100 * (last2$Total_kWh[2] / last2$Total_kWh[1] - 1)
  driver <- c(kitchen = last2$kitchen_kWh[2], laundry = last2$laundry_kWh[2],
              water_ac = last2$water_ac_kWh[2], rest = last2$rest_kWh[2])
  sprintf("Latest month %.0f kWh (Rs %.0f, %.0f kg CO2). Change vs previous month: %+.1f%%. Largest end-use that month: %s (%.0f kWh). Load factor %.2f. Solar 3 kWp self-consumption ~%.0f%%, simple payback ~%.1f years (illustrative INR overlay).",
          last2$Total_kWh[2], last2$Estimated_Bill_INR[2], last2$CO2_kg[2], chg,
          names(driver)[which.max(driver)], max(driver), last2$load_factor[2],
          pv_sum$self_consumption_pct, pv_sum$simple_payback_years)
} else "Insufficient months for a month-on-month insight."
writeLines(insight, file.path(PATHS$tables, "auto_insight.txt"))
cat(insight, "\n")

p <- ggplot(monthly, aes(YearMonth, Estimated_Bill_INR)) +
  geom_col(fill = "#3B6D91") +
  labs(title = "Illustrative monthly bill (TANGEDCO LT-IA slabs from Jul 2024)",
       subtitle = "Sceaux kWh x Indian tariff overlay — not a French electricity bill",
       x = "Month", y = "Rs")
safe_ggsave("27_monthly_bill.png", p, 10, 4)

p <- ggplot(monthly, aes(YearMonth, CO2_kg / 1000)) +
  geom_line(colour = "#6B8F71", linewidth = 1) +
  labs(title = "Illustrative CO2 using CEA FY 2023-24 factor 0.727 kg/kWh",
       x = "Month", y = "tCO2")
safe_ggsave("28_monthly_co2.png", p, 10, 4)

# Typical day solar vs load
typ <- df_pv %>%
  group_by(hour) %>%
  summarise(load = mean(kWh), pv = mean(pv_kWh), .groups = "drop") %>%
  pivot_longer(-hour)
p <- ggplot(typ, aes(hour, value, colour = name)) +
  geom_line(linewidth = 1) +
  labs(title = "Average hour: load vs simulated 3 kWp PV", x = "Hour", y = "kWh", colour = NULL)
safe_ggsave("29_solar_overlay.png", p, 7, 4)

print(head(monthly, 8))
cat("Cost module complete.\n")
