"""Build PNG/JSON assets for index.html from the UCI file + Open-Meteo weather."""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "household_power_consumption.txt"
WX = ROOT / "data" / "external" / "weather_sceaux.csv"
FIG = ROOT / "docs" / "assets"
FIG.mkdir(parents=True, exist_ok=True)
WEB = ROOT / "docs"
WEB.mkdir(exist_ok=True)

NAVY = "#1F3A4D"
STEEL = "#3B6D91"
RED = "#C44E52"
GOLD = "#C4A35A"
GREEN = "#6B8F71"
BG = "#F7F6F2"

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#D0D5DA",
    "axes.grid": True,
    "grid.color": "#EEF1F4",
    "grid.linewidth": 0.8,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.titleweight": "medium",
    "axes.labelsize": 10,
})


def tangedco_bimonthly(units: float) -> float:
    slabs = [(400, 4.80), (500, 6.45), (600, 8.55), (800, 9.65), (1000, 10.70), (float("inf"), 11.80)]
    remaining = max(units, 0.0)
    prev = 0.0
    bill = 0.0
    for upto, rate in slabs:
        span = min(remaining, upto - prev)
        if span > 0:
            bill += span * rate
            remaining -= span
        prev = upto
        if remaining <= 0:
            break
    return bill


def load_weather():
    temps = {}
    with WX.open(encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            key = row["Datetime"][:13]  # YYYY-MM-DDTHH
            try:
                temps[key] = float(row["temperature_c"])
            except (TypeError, ValueError):
                pass
    return temps


def stream_hourly():
    # hour_key -> sums
    power_sum = defaultdict(float)
    n = defaultdict(int)
    s1 = defaultdict(float)
    s2 = defaultdict(float)
    s3 = defaultdict(float)
    kwh = defaultdict(float)
    rows = 0
    na = 0
    with RAW.open(encoding="utf-8", errors="replace") as f:
        next(f)
        for line in f:
            rows += 1
            p = line.rstrip("\n").split(";")
            if len(p) < 9 or p[2] in ("", "?"):
                na += 1
                continue
            try:
                dd, mm, yy = p[0].split("/")
                hh = p[1].split(":")[0]
                hour_key = f"{int(yy):04d}-{int(mm):02d}-{int(dd):02d}T{int(hh):02d}"
                g = float(p[2])
                sm1, sm2, sm3 = float(p[6]), float(p[7]), float(p[8])
            except (ValueError, IndexError):
                na += 1
                continue
            power_sum[hour_key] += g
            n[hour_key] += 1
            s1[hour_key] += sm1
            s2[hour_key] += sm2
            s3[hour_key] += sm3
            kwh[hour_key] += g / 60.0
    keys = sorted(power_key for power_key in power_sum)
    mean_kw = np.array([power_sum[k] / n[k] for k in keys], dtype=np.float64)
    out = {
        "keys": keys,
        "mean_kw": mean_kw,
        "kwh": np.array([kwh[k] for k in keys], dtype=np.float64),
        "s1": np.array([s1[k] for k in keys], dtype=np.float64),
        "s2": np.array([s2[k] for k in keys], dtype=np.float64),
        "s3": np.array([s3[k] for k in keys], dtype=np.float64),
        "rows": rows,
        "na": na,
    }
    rest = out["kwh"] * 1000.0 - out["s1"] - out["s2"] - out["s3"]
    out["rest"] = np.clip(rest, 0, None)
    return out


def parse_key(k: str) -> datetime:
    return datetime.strptime(k, "%Y-%m-%dT%H")


def savefig(name: str):
    path = FIG / name
    plt.tight_layout()
    plt.savefig(path, dpi=140, bbox_inches="tight", facecolor="white")
    plt.close()
    return path.name


def main():
    print("Streaming UCI file...")
    h = stream_hourly()
    keys = h["keys"]
    dt = np.array([parse_key(k) for k in keys])
    kw = h["mean_kw"]
    kwh = h["kwh"]
    hours = np.array([t.hour for t in dt])
    months = np.array([t.month for t in dt])
    weekdays = np.array([t.weekday() for t in dt])  # 0=Mon
    years = np.array([t.year for t in dt])

    wx = load_weather()
    temp = np.array([wx.get(k, np.nan) for k in keys], dtype=np.float64)

    # daily
    day_keys = np.array([t.strftime("%Y-%m-%d") for t in dt])
    uniq_days, inv = np.unique(day_keys, return_inverse=True)
    daily_kwh = np.bincount(inv, weights=kwh)

    stats = {
        "n_minute": int(h["rows"]),
        "n_missing": int(h["na"]),
        "missing_pct": round(100 * h["na"] / h["rows"], 4),
        "n_hours": int(len(keys)),
        "n_days": int(len(uniq_days)),
        "start": keys[0],
        "end": keys[-1],
        "mean_kw": round(float(np.mean(kw)), 3),
        "median_kw": round(float(np.median(kw)), 3),
        "sd_kw": round(float(np.std(kw)), 3),
        "min_kw": round(float(np.min(kw)), 3),
        "max_kw": round(float(np.max(kw)), 3),
        "total_kwh": round(float(np.sum(kwh)), 1),
        "load_factor": round(float(np.mean(kw) / np.max(kw)), 3),
        "peak_time": keys[int(np.argmax(kw))],
    }

    # end use
    tot_s1, tot_s2, tot_s3, tot_rest = map(float, (h["s1"].sum(), h["s2"].sum(), h["s3"].sum(), h["rest"].sum()))
    tot = tot_s1 + tot_s2 + tot_s3 + tot_rest
    stats["share"] = {
        "Kitchen": round(100 * tot_s1 / tot, 2),
        "Laundry": round(100 * tot_s2 / tot, 2),
        "Water heater / AC": round(100 * tot_s3 / tot, 2),
        "Rest of house": round(100 * tot_rest / tot, 2),
    }

    # monthly bills
    month_keys = np.array([t.strftime("%Y-%m") for t in dt])
    um, invm = np.unique(month_keys, return_inverse=True)
    monthly_kwh = np.bincount(invm, weights=kwh)
    bills = np.array([tangedco_bimonthly(float(x) * 2) / 2 for x in monthly_kwh])
    co2 = monthly_kwh * 0.727
    stats["monthly_kwh_mean"] = round(float(np.mean(monthly_kwh)), 1)
    stats["bill_sum_inr"] = round(float(np.sum(bills)), 0)
    stats["co2_tonnes"] = round(float(np.sum(co2)) / 1000.0, 2)
    last = monthly_kwh[-1]
    stats["last_month_kwh"] = round(float(last), 1)
    stats["last_month_bill"] = round(tangedco_bimonthly(float(last) * 2) / 2, 0)
    if len(monthly_kwh) >= 2:
        stats["mom_pct"] = round(100 * (monthly_kwh[-1] / monthly_kwh[-2] - 1), 1)

    evening = (hours >= 18) & (hours < 22)
    night = hours < 6
    stats["evening_kw"] = round(float(np.mean(kw[evening])), 3)
    stats["night_kw"] = round(float(np.mean(kw[night])), 3)

    # ---- plots ----
    # 1 daily series
    day_dt = np.array([datetime.strptime(d, "%Y-%m-%d") for d in uniq_days])
    fig, ax = plt.subplots(figsize=(10.5, 3.6))
    ax.plot(day_dt, daily_kwh, color=STEEL, lw=0.8)
    ax.set_title("Daily energy use — Sceaux household (UCI, 2006–2010)")
    ax.set_xlabel("Date")
    ax.set_ylabel("kWh / day")
    savefig("01_daily_series.png")

    # 2 profile + IQR
    prof_mean, prof_lo, prof_hi = [], [], []
    for hr in range(24):
        sl = kw[hours == hr]
        prof_mean.append(sl.mean())
        prof_lo.append(np.quantile(sl, 0.25))
        prof_hi.append(np.quantile(sl, 0.75))
    fig, ax = plt.subplots(figsize=(7.2, 4))
    ax.fill_between(range(24), prof_lo, prof_hi, color=STEEL, alpha=0.2, label="IQR")
    ax.plot(range(24), prof_mean, color=STEEL, lw=2, label="Mean")
    ax.set_title("Average daily load profile (mean + IQR)")
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Active power (kW)")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(frameon=False)
    savefig("04_daily_profile.png")

    # 3 weekday weekend
    fig, ax = plt.subplots(figsize=(7.2, 4))
    for mask, lab, col in [
        (weekdays < 5, "Weekday", STEEL),
        (weekdays >= 5, "Weekend", RED),
    ]:
        m = [kw[(hours == hr) & mask].mean() for hr in range(24)]
        ax.plot(range(24), m, color=col, lw=2, label=lab)
    ax.set_title("Weekday vs weekend load profile")
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("kW")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(frameon=False)
    savefig("05_weekday_weekend.png")

    # 4 heatmap
    hm = np.zeros((12, 24))
    cnt = np.zeros((12, 24))
    for m, hr, v in zip(months, hours, kw):
        hm[m - 1, hr] += v
        cnt[m - 1, hr] += 1
    hm = np.divide(hm, np.maximum(cnt, 1))
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    im = ax.imshow(hm, aspect="auto", origin="upper", cmap="plasma")
    ax.set_yticks(range(12))
    ax.set_yticklabels(list("JFMAMJJASOND"))
    ax.set_xticks(range(0, 24, 2))
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Month")
    ax.set_title("Consumption heatmap: hour of day × month")
    fig.colorbar(im, ax=ax, label="kW")
    savefig("06_hour_month_heatmap.png")

    # 5 temp vs load
    ok = np.isfinite(temp)
    rng = np.random.default_rng(1)
    idx = np.where(ok)[0]
    if len(idx) > 8000:
        idx = rng.choice(idx, 8000, replace=False)
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.scatter(temp[idx], kw[idx], s=6, alpha=0.15, c=STEEL, linewidths=0)
    ax.set_title("Outdoor temperature vs hourly load (Sceaux, Open-Meteo)")
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("kW")
    savefig("13_temp_vs_load.png")

    # 6 submeter stacked by hour (Wh)
    fig, ax = plt.subplots(figsize=(8, 4.2))
    labs = ["Kitchen", "Laundry", "Water heater / AC", "Rest of house"]
    cols = [RED, GOLD, STEEL, GREEN]
    series = []
    for arr in (h["s1"], h["s2"], h["s3"], h["rest"]):
        series.append([arr[hours == hr].mean() for hr in range(24)])
    stack = np.vstack(series)
    ax.stackplot(range(24), stack, labels=labs, colors=cols, alpha=0.92)
    ax.set_title("Average hourly sub-meter energy")
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Wh (hourly sum)")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(loc="upper left", frameon=False, fontsize=8)
    savefig("14_submeter_stacked.png")

    # 7 share
    fig, ax = plt.subplots(figsize=(5.2, 5.2))
    vals = [tot_s1, tot_s2, tot_s3, tot_rest]
    ax.pie(vals, labels=labs, colors=cols, startangle=90,
           wedgeprops=dict(width=0.45, edgecolor="white"),
           autopct=lambda p: f"{p:.0f}%")
    ax.set_title("Share of measured energy by end-use")
    savefig("15_appliance_share.png")

    # 8 monthly bill
    month_dt = np.array([datetime.strptime(m, "%Y-%m") for m in um])
    fig, ax = plt.subplots(figsize=(10.5, 3.6))
    ax.bar(month_dt, bills, width=20, color=STEEL)
    ax.set_title("Illustrative monthly bill (TANGEDCO LT-IA slabs from Jul 2024)")
    ax.set_xlabel("Month")
    ax.set_ylabel("Rs")
    savefig("27_monthly_bill.png")

    # 9 solar overlay
    pv = 3 * np.maximum(np.sin(np.pi * (hours - 6) / 12), 0) * 0.5
    load_h = [kwh[hours == hr].mean() for hr in range(24)]
    pv_h = [pv[hours == hr].mean() for hr in range(24)]
    fig, ax = plt.subplots(figsize=(7.2, 4))
    ax.plot(range(24), load_h, color=NAVY, lw=2, label="Load")
    ax.plot(range(24), pv_h, color=GOLD, lw=2, label="Simulated 3 kWp PV")
    ax.set_title("Average hour: household load vs simulated rooftop PV")
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("kWh")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(frameon=False)
    savefig("29_solar_overlay.png")

    # 10 box by hour
    fig, ax = plt.subplots(figsize=(9.5, 4))
    data = [kw[hours == hr] for hr in range(24)]
    bp = ax.boxplot(data, positions=range(24), widths=0.6, showfliers=False,
                    patch_artist=True)
    for box in bp["boxes"]:
        box.set_facecolor(STEEL)
        box.set_alpha(0.7)
    ax.set_title("Hourly power distribution")
    ax.set_xlabel("Hour")
    ax.set_ylabel("kW")
    savefig("08_box_hour.png")

    # 11 calendar-ish daily heatmap by year-week
    fig, axes = plt.subplots(len(np.unique(years)), 1, figsize=(10.5, 2.2 * len(np.unique(years))), sharex=False)
    if not hasattr(axes, "__len__"):
        axes = [axes]
    for ax, y in zip(axes, sorted(set(years.tolist()))):
        mask = np.array([datetime.strptime(d, "%Y-%m-%d").year == y for d in uniq_days])
        days = day_dt[mask]
        vals = daily_kwh[mask]
        week = np.array([d.isocalendar()[1] for d in days])
        wd = np.array([d.weekday() for d in days])
        grid = np.full((7, 54), np.nan)
        for w, d, v in zip(week, wd, vals):
            if 1 <= w <= 53:
                grid[d, w] = v
        im = ax.imshow(grid, aspect="auto", cmap="magma", interpolation="nearest")
        ax.set_yticks(range(7))
        ax.set_yticklabels(list("MTWTFSS"))
        ax.set_ylabel(str(y))
        ax.set_xticks([])
    axes[0].set_title("Calendar heatmap of daily kWh")
    axes[-1].set_xlabel("ISO week")
    fig.colorbar(im, ax=axes, fraction=0.02, label="kWh")
    savefig("07_calendar_heatmap.png")

    # ---- simple chronological hourly forecast metrics ----
    # last 7 days test, previous 8 weeks train; snaive lag 168 vs lag+hour+temp OLS
    end = dt[-1]
    test_start = end - timedelta(days=7)
    train_start = test_start - timedelta(weeks=8)
    is_test = dt > test_start
    is_train = (dt > train_start) & (dt <= test_start)
    y = kw
    lag168 = np.full_like(y, np.nan)
    lag24 = np.full_like(y, np.nan)
    # keys are hourly but may have gaps — use position lag only if consecutive hours
    epoch = np.array([int(t.timestamp()) for t in dt])
    hour_index = {int(e): i for i, e in enumerate(epoch)}
    for i, e in enumerate(epoch):
        j24 = hour_index.get(e - 24 * 3600)
        j168 = hour_index.get(e - 168 * 3600)
        if j24 is not None:
            lag24[i] = y[j24]
        if j168 is not None:
            lag168[i] = y[j168]

    def metrics(actual, pred):
        m = np.isfinite(actual) & np.isfinite(pred)
        a, p = actual[m], pred[m]
        err = a - p
        mae = float(np.mean(np.abs(err)))
        rmse = float(np.sqrt(np.mean(err**2)))
        mape = float(100 * np.mean(np.abs(err) / np.maximum(np.abs(a), 1e-3)))
        sst = float(np.sum((a - a.mean()) ** 2))
        r2 = float(1 - np.sum(err**2) / sst) if sst > 0 else None
        naive = np.abs(np.diff(a))
        mase = mae / float(np.mean(naive)) if len(naive) else None
        return {"n": int(m.sum()), "RMSE": round(rmse, 4), "MAE": round(mae, 4),
                "MAPE": round(mape, 2), "MASE": None if mase is None else round(mase, 3),
                "R2": None if r2 is None else round(r2, 3)}

    snaive_pred = lag168
    m_sn = metrics(y[is_test], snaive_pred[is_test])
    m_sn["model"] = "Seasonal naive (lag 168h)"

    # OLS on train: y ~ lag168 + lag24 + hour dummies + temp
    tr = is_train & np.isfinite(lag168) & np.isfinite(lag24) & np.isfinite(temp)
    te = is_test & np.isfinite(lag168) & np.isfinite(lag24) & np.isfinite(temp)
    hd_tr = np.eye(24)[hours[tr]]
    hd_te = np.eye(24)[hours[te]]
    Xtr = np.column_stack([np.ones(tr.sum()), lag168[tr], lag24[tr], temp[tr], hd_tr[:, 1:]])
    Xte = np.column_stack([np.ones(te.sum()), lag168[te], lag24[te], temp[te], hd_te[:, 1:]])
    beta, *_ = np.linalg.lstsq(Xtr, y[tr], rcond=None)
    lm_pred = Xte @ beta
    m_lm = metrics(y[te], lm_pred)
    m_lm["model"] = "Linear: lags + hour + temperature"

    stats["holdout"] = {
        "grain": "hourly",
        "test_hours": int(is_test.sum()),
        "train_start": train_start.isoformat(sep=" ", timespec="hours"),
        "test_start": test_start.isoformat(sep=" ", timespec="hours"),
        "models": [m_sn, m_lm],
        "note": "Chronological 7-day holdout computed for this portal. Full ARIMA/XGBoost/RF leaderboard is produced by R/05_models.R.",
    }

    # actual vs snaive plot on test
    fig, ax = plt.subplots(figsize=(10.5, 3.8))
    t_test = dt[is_test]
    ax.plot(t_test, y[is_test], color=NAVY, lw=1, label="Actual")
    ax.plot(t_test, snaive_pred[is_test], color=RED, lw=1, label="Seasonal naive (lag 168)")
    ax.set_title("Test week: actual vs seasonal-naive baseline")
    ax.set_xlabel("Time")
    ax.set_ylabel("kW")
    ax.legend(frameon=False)
    savefig("20_actual_vs_pred.png")

    stats["figures"] = sorted(p.name for p in FIG.glob("*.png"))
    (WEB / "stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps({k: stats[k] for k in ("n_minute", "n_missing", "total_kwh", "load_factor", "holdout")}, indent=2))
    print("Wrote", WEB / "stats.json", "and", len(stats["figures"]), "figures")


if __name__ == "__main__":
    main()
