# 00_utils.R — shared paths, calendars, tariffs, metrics
# Source this from any script or from the Shiny app.

find_project_root <- function() {
  walk <- function(start) {
    d <- normalizePath(start, winslash = "/", mustWork = FALSE)
    for (i in 1:8) {
      if (file.exists(file.path(d, "Electricity-Consumption-Forecasting.Rproj")) ||
          (dir.exists(file.path(d, "R")) && dir.exists(file.path(d, "data")))) {
        return(d)
      }
      parent <- dirname(d)
      if (identical(parent, d)) break
      d <- parent
    }
    NULL
  }

  ofile <- NULL
  if (!is.null(sys.frame(1)$ofile)) ofile <- sys.frame(1)$ofile
  candidates <- c(getwd(), if (!is.null(ofile)) dirname(ofile), if (!is.null(ofile)) file.path(dirname(ofile), ".."))
  for (c in candidates) {
    hit <- walk(c)
    if (!is.null(hit)) return(hit)
  }
  normalizePath(getwd(), winslash = "/")
}

PROJECT_ROOT <- find_project_root()
PATHS <- list(
  root      = PROJECT_ROOT,
  raw       = file.path(PROJECT_ROOT, "data", "raw"),
  processed = file.path(PROJECT_ROOT, "data", "processed"),
  external  = file.path(PROJECT_ROOT, "data", "external"),
  ref       = file.path(PROJECT_ROOT, "data", "reference"),
  figures   = file.path(PROJECT_ROOT, "outputs", "figures"),
  models    = file.path(PROJECT_ROOT, "outputs", "models"),
  forecasts = file.path(PROJECT_ROOT, "outputs", "forecasts"),
  tables    = file.path(PROJECT_ROOT, "outputs", "tables")
)

ensure_project_dirs <- function() {
  invisible(lapply(PATHS, function(p) if (!dir.exists(p)) dir.create(p, recursive = TRUE)))
}

raw_txt_path <- function() file.path(PATHS$raw, "household_power_consumption.txt")

# ---------------------------------------------------------------------------
# Domain constants (cited in the report)
# ---------------------------------------------------------------------------
# CEA CO2 Baseline Database Version 20.0 (Dec 2024), FY 2023-24
# weighted-average grid emission factor including RE: 0.727 tCO2/MWh = 0.727 kg/kWh
CO2_KG_PER_KWH <- 0.727

# TNERC / TNPDCL LT-IA domestic energy charges from 1 July 2024 (bi-monthly, Rs/kWh)
# Source: TNERC Tariff Order, The Hindu 4 Jul 2024 (500 units -> Rs 2,565 check)
TANGEDCO_SLABS_BIMONTHLY <- data.frame(
  upto = c(400, 500, 600, 800, 1000, Inf),
  rate = c(4.80, 6.45, 8.55, 9.65, 10.70, 11.80)
)

# Illustrative ToD overlay from TNERC HT/LT ToD windows (not charged on LT-IA domestic,
# but used for the load-shifting simulator). Peak +25%, off-peak -5%.
TOD_PEAK_HOURS     <- c(6:9, 18:21)   # 06:00-10:00 and 18:00-22:00
TOD_OFFPEAK_HOURS  <- c(22:23, 0:4)   # 22:00-05:00

tangedco_bill_bimonthly <- function(units) {
  units <- pmax(units, 0)
  vapply(units, function(u) {
    remaining <- u
    prev <- 0
    bill <- 0
    for (i in seq_len(nrow(TANGEDCO_SLABS_BIMONTHLY))) {
      span <- min(remaining, TANGEDCO_SLABS_BIMONTHLY$upto[i] - prev)
      if (span > 0) {
        bill <- bill + span * TANGEDCO_SLABS_BIMONTHLY$rate[i]
        remaining <- remaining - span
      }
      prev <- TANGEDCO_SLABS_BIMONTHLY$upto[i]
      if (remaining <= 0) break
    }
    bill
  }, numeric(1))
}

tod_slot <- function(hour) {
  ifelse(hour %in% TOD_PEAK_HOURS, "Peak",
         ifelse(hour %in% TOD_OFFPEAK_HOURS, "OffPeak", "Normal"))
}

tn_season <- function(month) {
  dplyr::case_when(
    month %in% c(12, 1, 2) ~ "Winter",
    month %in% c(3, 4, 5)  ~ "Summer",
    month %in% c(6, 7, 8, 9) ~ "Monsoon",
    TRUE ~ "PostMonsoon"
  )
}

meteo_season <- function(month) {
  dplyr::case_when(
    month %in% c(12, 1, 2) ~ "DJF_Winter",
    month %in% c(3, 4, 5)  ~ "MAM_Spring",
    month %in% c(6, 7, 8)  ~ "JJA_Summer",
    TRUE ~ "SON_Autumn"
  )
}

# Indian public holidays (national + TN-relevant) 2006-2011 — course overlay
india_holiday_dates <- as.Date(c(
  # New Year, Republic Day, May Day, Independence, Gandhi Jayanti, Christmas, Pongal
  "2006-12-25", "2007-01-01", "2007-01-14", "2007-01-15", "2007-01-26",
  "2007-05-01", "2007-08-15", "2007-10-02", "2007-12-25",
  "2008-01-01", "2008-01-14", "2008-01-15", "2008-01-26",
  "2008-05-01", "2008-08-15", "2008-10-02", "2008-10-09", "2008-12-25", # Diwali ~9 Oct 2008
  "2009-01-01", "2009-01-14", "2009-01-15", "2009-01-26",
  "2009-05-01", "2009-08-15", "2009-10-02", "2009-10-17", "2009-12-25",
  "2010-01-01", "2010-01-14", "2010-01-15", "2010-01-26",
  "2010-05-01", "2010-08-15", "2010-10-02", "2010-11-05", "2010-12-25",
  "2011-01-01", "2011-01-14", "2011-01-26"
))

# French public holidays physically matching Sceaux (used in models)
france_holiday_dates <- as.Date(c(
  "2006-12-25", "2007-01-01", "2007-04-09", "2007-05-01", "2007-05-08",
  "2007-05-17", "2007-05-28", "2007-07-14", "2007-08-15", "2007-11-01",
  "2007-11-11", "2007-12-25",
  "2008-01-01", "2008-03-24", "2008-05-01", "2008-05-08", "2008-05-12",
  "2008-05-24", "2008-07-14", "2008-08-15", "2008-11-01", "2008-11-11",
  "2008-12-25",
  "2009-01-01", "2009-04-13", "2009-05-01", "2009-05-08", "2009-05-21",
  "2009-06-01", "2009-07-14", "2009-08-15", "2009-11-01", "2009-11-11",
  "2009-12-25",
  "2010-01-01", "2010-04-05", "2010-05-01", "2010-05-08", "2010-05-13",
  "2010-05-24", "2010-07-14", "2010-08-15", "2010-11-01", "2010-11-11",
  "2010-12-25"
))

# Paris/Sceaux monthly mean temperatures used if Open-Meteo file is absent
PARIS_MONTHLY_MEAN_C <- c(4.3, 5.0, 8.0, 11.0, 15.0, 18.0, 20.0, 19.7, 16.5, 12.0, 7.5, 5.0)

climatology_temp <- function(datetime) {
  m <- lubridate::month(datetime)
  h <- lubridate::hour(datetime)
  doy <- lubridate::yday(datetime)
  base <- PARIS_MONTHLY_MEAN_C[m]
  # diurnal amplitude ~6 C, peak around 15:00
  diurnal <- 3 * cos((h - 15) * 2 * pi / 24)
  data.frame(
    temperature_c = base + diurnal,
    relative_humidity = pmin(95, pmax(40, 75 - 1.2 * diurnal)),
    temp_source = "climatology_proxy"
  )
}

forecast_metrics <- function(actual, predicted) {
  ok <- is.finite(actual) & is.finite(predicted)
  y <- actual[ok]; yhat <- predicted[ok]
  if (length(y) < 2) {
    return(data.frame(n = length(y), RMSE = NA, MAE = NA, MdAE = NA,
                      MAPE = NA, sMAPE = NA, MASE = NA, R2 = NA))
  }
  err <- y - yhat
  mae <- mean(abs(err))
  naive_mae <- mean(abs(diff(y)))
  sse <- sum(err^2); sst <- sum((y - mean(y))^2)
  data.frame(
    n     = length(y),
    RMSE  = sqrt(mean(err^2)),
    MAE   = mae,
    MdAE  = stats::median(abs(err)),
    MAPE  = 100 * mean(abs(err) / pmax(abs(y), 1e-6)),
    sMAPE = 100 * mean(2 * abs(err) / pmax(abs(y) + abs(yhat), 1e-6)),
    MASE  = if (naive_mae > 0) mae / naive_mae else NA_real_,
    R2    = if (sst > 0) 1 - sse / sst else NA_real_
  )
}

safe_ggsave <- function(filename, plot, width = 8, height = 4.5) {
  ensure_project_dirs()
  ggplot2::ggsave(file.path(PATHS$figures, filename), plot = plot, width = width, height = height, dpi = 120)
}

write_table <- function(df, filename) {
  ensure_project_dirs()
  utils::write.csv(df, file.path(PATHS$tables, filename), row.names = FALSE)
  utils::write.csv(df, file.path(PATHS$forecasts, filename), row.names = FALSE)
}

pkg_available <- function(pkgs) {
  vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)
}

message_header <- function(title) {
  cat("\n", strrep("=", 64), "\n", title, "\n", strrep("=", 64), "\n", sep = "")
}
