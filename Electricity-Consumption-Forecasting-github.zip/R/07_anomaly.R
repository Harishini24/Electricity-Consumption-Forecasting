# 07_anomaly.R — IQR/STL remainder, theft-pattern injection test, changepoints

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(lubridate)
})

message_header("07  Anomaly detection")
path <- file.path(PATHS$processed, "df_hourly.rds")
if (!file.exists(path)) stop("Run 02_clean.R first.")
df <- readRDS(path) %>% arrange(Datetime) %>% filter(!is.na(Global_active_power))

# STL remainder + IQR fences (anomalize-style, no extra package required)
x <- ts(df$Global_active_power, frequency = 24)
stl_fit <- try(stl(x, s.window = "periodic", robust = TRUE), silent = TRUE)
if (!inherits(stl_fit, "try-error")) {
  rem <- as.numeric(stl_fit$time.series[, "remainder"])
} else {
  rem <- as.numeric(df$Global_active_power - zoo::rollmedian(df$Global_active_power, 25, fill = NA))
}
iq <- quantile(rem, c(0.25, 0.75), na.rm = TRUE)
fence <- 3 * IQR(rem, na.rm = TRUE)
lo <- iq[1] - fence; hi <- iq[2] + fence

anom <- df %>%
  mutate(
    remainder = rem,
    expected = Global_active_power - rem,
    deviation = remainder,
    anomaly = remainder < lo | remainder > hi,
    severity = case_when(
      is.na(remainder) ~ "NA",
      remainder < lo | remainder > hi ~ ifelse(abs(remainder) > 2 * fence, "high", "medium"),
      TRUE ~ "normal"
    ),
    type = case_when(
      !anomaly ~ "none",
      remainder < lo ~ "point_low",
      TRUE ~ "point_high"
    )
  )

# Sequential / collective: runs of 3+ consecutive point flags
r <- rle(anom$anomaly)
run_id <- rep(seq_along(r$lengths), r$lengths)
anom$collective <- FALSE
for (i in which(r$values & r$lengths >= 3)) {
  idx <- which(run_id == i)
  anom$collective[idx] <- TRUE
  anom$type[idx] <- "collective"
}

log <- anom %>%
  filter(anomaly) %>%
  transmute(Datetime, actual = Global_active_power, expected, deviation, severity, type, collective)
write_table(log, "anomaly_log.csv")
cat(sprintf("Flagged %d point anomalies (%.2f%% of hours); %d belong to collective runs.\n",
            nrow(log), 100 * nrow(log) / nrow(anom), sum(log$collective)))

p <- ggplot(anom %>% filter(Datetime >= max(Datetime) - lubridate::days(60)),
            aes(Datetime, Global_active_power)) +
  geom_line(colour = "#3B6D91", alpha = 0.8) +
  geom_point(data = function(d) dplyr::filter(d, anomaly), colour = "#C44E52", size = 1.2) +
  labs(title = "Anomalies on the last 60 days (red = remainder outside 3xIQR)",
       x = "Time", y = "kW")
safe_ggsave("23_anomalies.png", p, 10, 4)

# Synthetic theft / meter-fault patterns on a clean week — detector recall
set.seed(42)
clean <- tail(df, 24 * 21)
truth <- data.frame(Datetime = clean$Datetime, injected = FALSE, pattern = "none")
y <- clean$Global_active_power
# 1. single-point zeroing
truth$injected[100] <- TRUE; truth$pattern[100] <- "single_zero"; y[100] <- 0
# 2. interval zeroing 6h
truth$injected[200:205] <- TRUE; truth$pattern[200:205] <- "interval_zero"; y[200:205] <- 0
# 3. peak clipping
pk <- which.max(y[240:264]) + 239
truth$injected[pk] <- TRUE; truth$pattern[pk] <- "peak_clip"; y[pk] <- y[pk] * 0.4
# 4. random reduction 20% for a day
truth$injected[300:323] <- TRUE; truth$pattern[300:323] <- "random_reduction"; y[300:323] <- y[300:323] * 0.8

rem2 <- y - as.numeric(zoo::rollmedian(y, 25, fill = median(y, na.rm = TRUE)))
iq2 <- quantile(rem2, c(0.25, 0.75), na.rm = TRUE)
hit <- rem2 < (iq2[1] - 3 * IQR(rem2)) | rem2 > (iq2[2] + 3 * IQR(rem2)) | y < 0.05
recall <- sum(hit & truth$injected) / sum(truth$injected)
precision <- sum(hit & truth$injected) / max(sum(hit), 1)
inj <- data.frame(recall = recall, precision = precision, n_injected = sum(truth$injected), n_flagged = sum(hit))
write_table(inj, "anomaly_injection_test.csv")
cat(sprintf("Injection test recall=%.2f precision=%.2f (illustrative, not a certified AMI detector).\n",
            recall, precision))

if (requireNamespace("changepoint", quietly = TRUE) && file.exists(file.path(PATHS$processed, "df_daily.rds"))) {
  d <- readRDS(file.path(PATHS$processed, "df_daily.rds"))
  d <- d %>% filter(!is.na(kWh))
  cpt <- try(changepoint::cpt.mean(d$kWh, method = "PELT"), silent = TRUE)
  if (!inherits(cpt, "try-error")) {
    cps <- changepoint::cpts(cpt)
    cp_tbl <- data.frame(index = cps, Date = d$Datetime[cps], kWh = d$kWh[cps])
    write_table(cp_tbl, "changepoints_daily.csv")
    p <- ggplot(d, aes(Datetime, kWh)) +
      geom_line(colour = "#3B6D91") +
      geom_vline(xintercept = d$Datetime[cps], colour = "#C44E52", linetype = "dashed") +
      labs(title = "PELT changepoints on daily kWh", x = "Date", y = "kWh")
    safe_ggsave("24_changepoints.png", p, 10, 4)
  }
}

saveRDS(anom, file.path(PATHS$processed, "df_anomalies.rds"))
cat("Anomaly module complete.\n")
