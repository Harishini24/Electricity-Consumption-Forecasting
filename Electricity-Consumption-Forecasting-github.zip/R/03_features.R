# 03_features.R
# Feature Engineering

library(dplyr)
library(lubridate)
library(timetk)
library(tsibble)

cat("Starting Feature Engineering...\n")

if(file.exists("../data/processed/df_hourly.rds")) {
  df_ts <- readRDS("../data/processed/df_hourly.rds")
  
  # 1. Flag contamination near gaps
  # A gap is any row where Global_active_power is NA.
  # If a row is within 168 hours AFTER an NA, its rolling features are contaminated.
  # We flag this by doing a rolling sum of NAs over the past 168 hours.
  
  df_features <- df_ts %>%
    as_tibble() %>%
    mutate(is_na = is.na(Global_active_power)) %>%
    mutate(
      na_in_past_168 = slidify_vec(
        .x      = is_na,
        .f      = sum,
        .period = 168,
        .align  = "right",
        .partial = TRUE
      )
    ) %>%
    mutate(near_gap = ifelse(na_in_past_168 > 0, TRUE, FALSE)) %>%
    select(-is_na, -na_in_past_168)
  
  # 2. Calendar Features
  df_features <- df_features %>%
    mutate(
      hour = hour(Datetime),
      day_of_week = wday(Datetime, label = TRUE),
      day_of_month = mday(Datetime),
      month = month(Datetime, label = TRUE),
      year = year(Datetime),
      is_weekend = ifelse(day_of_week %in% c("Sat", "Sun"), 1, 0),
      time_of_day = case_when(
        hour >= 6 & hour < 12 ~ "Morning",
        hour >= 12 & hour < 18 ~ "Afternoon",
        hour >= 18 & hour < 22 ~ "Evening_Peak",
        TRUE ~ "Night"
      )
    )
    
  # 3. Lag & Window Features (on Global_active_power)
  df_features <- df_features %>%
    tk_augment_lags(Global_active_power, .lags = c(1, 24, 168)) %>%
    tk_augment_slidify(
      .value   = Global_active_power,
      .f       = ~mean(.x, na.rm = FALSE), 
      .period  = c(24, 168),
      .align   = "right",
      .partial = FALSE
    )
    
  # 4. Drop NAs from training data
  # This naturally drops the large gaps and the first 168 leading rows.
  # We keep near_gap rows but flag them so they can be excluded in model evaluation if desired.
  
  df_features_clean <- df_features %>%
    tidyr::drop_na(Global_active_power, Global_active_power_lag168)
  
  saveRDS(df_features_clean, "../data/processed/df_features.rds")
  write.csv(df_features_clean, "../data/processed/electricity_features.csv", row.names = FALSE)
  
  cat(sprintf("Feature engineering complete. Final row count: %d\n", nrow(df_features_clean)))
  cat(sprintf("Contaminated near_gap rows flagged: %d\n", sum(df_features_clean$near_gap)))
  cat("Saved to data/processed/df_features.rds and .csv\n")
  
} else {
  cat("df_hourly.rds not found. Run 02_clean.R first.\n")
}
