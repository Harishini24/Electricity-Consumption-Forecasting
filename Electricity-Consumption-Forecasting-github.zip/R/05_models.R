# 05_models.R — chronological split, classical + ML, no random sampling
# Daily grain for ARIMA/ETS/STL/Prophet; hourly grain for snaive + XGBoost/RF.

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(lubridate)
})

message_header("05  Forecasting models")
daily_path <- file.path(PATHS$processed, "df_daily_features.rds")
feat_path  <- file.path(PATHS$processed, "df_features.rds")
if (!file.exists(daily_path) || !file.exists(feat_path)) stop("Run 03_features.R first.")

daily <- readRDS(daily_path) %>% arrange(Datetime) %>% filter(!is.na(kWh))
hourly <- readRDS(feat_path) %>% arrange(Datetime)

# ---- NEVER random-split a time series ----
# Daily: last 30 days held out (1-month horizon)
n_d <- nrow(daily)
test_d <- 30
train_d <- daily[1:(n_d - test_d), ]
test_daily <- daily[(n_d - test_d + 1):n_d, ]
ytr <- ts(train_d$kWh, frequency = 7)

fit_and_fc <- function(name, fit, h, actual) {
  t0 <- proc.time()[3]
  obj <- try(fit, silent = TRUE)
  elapsed <- proc.time()[3] - t0
  if (inherits(obj, "try-error")) {
    cat("  SKIP", name, ":", as.character(obj), "\n")
    return(NULL)
  }
  fc <- try(forecast::forecast(obj, h = h), silent = TRUE)
  if (inherits(fc, "try-error")) return(NULL)
  point <- as.numeric(fc$mean)
  lo80 <- if (!is.null(fc$lower)) fc$lower[, 1] else point
  hi80 <- if (!is.null(fc$upper)) fc$upper[, 1] else point
  lo95 <- if (!is.null(fc$lower) && ncol(fc$lower) >= 2) fc$lower[, 2] else point
  hi95 <- if (!is.null(fc$upper) && ncol(fc$upper) >= 2) fc$upper[, 2] else point
  m <- forecast_metrics(actual, point)
  m$model <- name
  m$runtime_sec <- round(elapsed, 2)
  m$grain <- "daily"
  m$horizon <- "30-day"
  list(metrics = m, fc = data.frame(
    Datetime = test_daily$Datetime, model = name,
    actual = actual, point_forecast = point,
    lo_80 = lo80, hi_80 = hi80, lo_95 = lo95, hi_95 = hi95
  ), fit = obj)
}

results <- list()
if (requireNamespace("forecast", quietly = TRUE)) {
  cat("Daily models on chronological 30-day holdout...\n")
  h <- nrow(test_daily)
  act <- test_daily$kWh
  results$snaive <- fit_and_fc("SeasonalNaive_lag7", forecast::snaive(ytr, h = h), h, act)
  results$naive  <- fit_and_fc("Naive", forecast::naive(ytr, h = h), h, act)
  results$ses    <- fit_and_fc("SES", forecast::ets(ytr, model = "ANN"), h, act)
  results$holt   <- fit_and_fc("Holt", forecast::ets(ytr, model = "AAN"), h, act)
  results$hw     <- fit_and_fc("HoltWinters_ets", forecast::ets(ytr, model = "AAA"), h, act)
  results$ets    <- fit_and_fc("ETS_auto", forecast::ets(ytr), h, act)
  results$arima  <- fit_and_fc("auto.arima",
    forecast::auto.arima(ytr, stepwise = TRUE, approximation = TRUE, seasonal = TRUE), h, act)
  results$stlm   <- fit_and_fc("STL_ETS", forecast::stlm(ytr, method = "ets"), h, act)
  results$nnetar <- fit_and_fc("NNETAR",
    forecast::nnetar(ytr, p = 7, size = 3, repeats = 5), h, act)
  # TSLM-style regression + SARIMAX with temperature and holidays
  if (requireNamespace("forecast", quietly = TRUE)) {
    t0 <- proc.time()[3]
    tslm_df <- data.frame(
      kWh = as.numeric(ytr),
      trend = seq_along(ytr),
      temp = train_d$temperature_c,
      holiday = train_d$is_holiday,
      sinw = train_d$sin_w,
      cosw = train_d$cos_w
    )
    fit_tslm <- try(lm(kWh ~ trend + temp + holiday + sinw + cosw, data = tslm_df), silent = TRUE)
    if (!inherits(fit_tslm, "try-error")) {
      newdata <- data.frame(
        trend = nrow(tslm_df) + seq_len(h),
        temp = test_daily$temperature_c,
        holiday = test_daily$is_holiday,
        sinw = test_daily$sin_w,
        cosw = test_daily$cos_w
      )
      pred <- as.numeric(predict(fit_tslm, newdata = newdata))
      m_t <- forecast_metrics(act, pred)
      m_t$model <- "TSLM_trend_temp_fourier"
      m_t$runtime_sec <- round(proc.time()[3] - t0, 2)
      m_t$grain <- "daily"; m_t$horizon <- "30-day"
      results$tslm <- list(metrics = m_t, fc = data.frame(
        Datetime = test_daily$Datetime, model = m_t$model, actual = act,
        point_forecast = pred, lo_80 = pred, hi_80 = pred, lo_95 = pred, hi_95 = pred
      ), fit = fit_tslm)
    }
    fit_arimax <- try(forecast::auto.arima(ytr, xreg = as.matrix(data.frame(
      temp = train_d$temperature_c, holiday = train_d$is_holiday,
      sinw = train_d$sin_w, cosw = train_d$cos_w
    )), stepwise = TRUE, approximation = TRUE), silent = TRUE)
    elapsed <- proc.time()[3] - t0
    if (!inherits(fit_arimax, "try-error")) {
      fc <- forecast::forecast(fit_arimax, h = h, xreg = as.matrix(data.frame(
        temp = test_daily$temperature_c, holiday = test_daily$is_holiday,
        sinw = test_daily$sin_w, cosw = test_daily$cos_w
      )))
      m <- forecast_metrics(act, as.numeric(fc$mean))
      m$model <- "SARIMAX_temp_holiday"
      m$runtime_sec <- round(elapsed, 2); m$grain <- "daily"; m$horizon <- "30-day"
      results$sarimax <- list(metrics = m, fc = data.frame(
        Datetime = test_daily$Datetime, model = m$model, actual = act,
        point_forecast = as.numeric(fc$mean),
        lo_80 = fc$lower[, 1], hi_80 = fc$upper[, 1],
        lo_95 = fc$lower[, 2], hi_95 = fc$upper[, 2]
      ), fit = fit_arimax)
    }
  }
  if (requireNamespace("prophet", quietly = TRUE)) {
    cat("  Prophet...\n")
    t0 <- proc.time()[3]
    pr_df <- data.frame(ds = as.Date(train_d$Datetime), y = train_d$kWh)
    pr <- try(prophet::prophet(pr_df, daily.seasonality = FALSE,
                               weekly.seasonality = TRUE, yearly.seasonality = TRUE), silent = TRUE)
    elapsed <- proc.time()[3] - t0
    if (!inherits(pr, "try-error")) {
      future <- prophet::make_future_dataframe(pr, periods = h)
      fc <- prophet::predict(pr, future)
      point <- tail(fc$yhat, h)
      m <- forecast_metrics(act, point)
      m$model <- "Prophet"; m$runtime_sec <- round(elapsed, 2); m$grain <- "daily"; m$horizon <- "30-day"
      results$prophet <- list(metrics = m, fc = data.frame(
        Datetime = test_daily$Datetime, model = "Prophet", actual = act,
        point_forecast = point, lo_80 = tail(fc$yhat_lower, h), hi_80 = tail(fc$yhat_upper, h),
        lo_95 = tail(fc$yhat_lower, h), hi_95 = tail(fc$yhat_upper, h)
      ), fit = pr)
    }
  }
}

# Hourly 24-h ahead on last 14 days, trained on previous 8 weeks (chronological)
cat("Hourly 24-hour-ahead models (last 14 days x 24h walk-forward origin = last week block)...\n")
h_end <- max(hourly$Datetime, na.rm = TRUE)
hourly_win <- hourly %>%
  filter(Datetime > h_end - lubridate::weeks(10), !is.na(Global_active_power), !is.na(lag_24), !is.na(lag_168))
split_at <- h_end - lubridate::days(7)
train_h <- hourly_win %>% filter(Datetime <= split_at)
test_h  <- hourly_win %>% filter(Datetime > split_at)

# Seasonal naive 168
snaive_h <- test_h$lag_168
m_sn <- forecast_metrics(test_h$Global_active_power, snaive_h)
m_sn$model <- "SeasonalNaive_lag168"; m_sn$runtime_sec <- 0; m_sn$grain <- "hourly"; m_sn$horizon <- "7-day (168h seasonal naive)"
results$snaive_h <- list(metrics = m_sn, fc = data.frame(
  Datetime = test_h$Datetime, model = m_sn$model,
  actual = test_h$Global_active_power, point_forecast = snaive_h,
  lo_80 = snaive_h, hi_80 = snaive_h, lo_95 = snaive_h, hi_95 = snaive_h
))

# Linear regression with calendar + lags + weather
x_cols <- c("hour", "day_of_week_num", "month_num", "is_weekend", "is_holiday",
            "lag_1", "lag_24", "lag_168", "temperature_c", "temperature_sq", "CDD", "HDD",
            "sin_d1", "cos_d1", "sin_w1", "cos_w1")
form <- as.formula(paste("Global_active_power ~", paste(x_cols, collapse = " + ")))
t0 <- proc.time()[3]
fit_lm <- lm(form, data = train_h)
pred_lm <- predict(fit_lm, newdata = test_h)
elapsed <- proc.time()[3] - t0
m_lm <- forecast_metrics(test_h$Global_active_power, pred_lm)
m_lm$model <- "TSLM_lags_weather"; m_lm$runtime_sec <- round(elapsed, 2)
m_lm$grain <- "hourly"; m_lm$horizon <- "7-day holdout"
results$lm_h <- list(metrics = m_lm, fc = data.frame(
  Datetime = test_h$Datetime, model = m_lm$model,
  actual = test_h$Global_active_power, point_forecast = as.numeric(pred_lm),
  lo_80 = NA, hi_80 = NA, lo_95 = NA, hi_95 = NA
), fit = fit_lm)

if (requireNamespace("rpart", quietly = TRUE)) {
  t0 <- proc.time()[3]
  fit_tree <- rpart::rpart(form, data = train_h, method = "anova")
  pred <- predict(fit_tree, test_h)
  elapsed <- proc.time()[3] - t0
  m <- forecast_metrics(test_h$Global_active_power, pred)
  m$model <- "CART"; m$runtime_sec <- round(elapsed, 2); m$grain <- "hourly"; m$horizon <- "7-day holdout"
  results$cart <- list(metrics = m, fc = data.frame(
    Datetime = test_h$Datetime, model = m$model, actual = test_h$Global_active_power,
    point_forecast = as.numeric(pred), lo_80 = NA, hi_80 = NA, lo_95 = NA, hi_95 = NA
  ), fit = fit_tree)
}

if (requireNamespace("ranger", quietly = TRUE)) {
  cat("  Random Forest (ranger)...\n")
  t0 <- proc.time()[3]
  fit_rf <- ranger::ranger(form, data = train_h, num.trees = 200, importance = "impurity", seed = 123)
  pred <- predict(fit_rf, data = test_h)$predictions
  elapsed <- proc.time()[3] - t0
  m <- forecast_metrics(test_h$Global_active_power, pred)
  m$model <- "RandomForest"; m$runtime_sec <- round(elapsed, 2); m$grain <- "hourly"; m$horizon <- "7-day holdout"
  results$rf <- list(metrics = m, fc = data.frame(
    Datetime = test_h$Datetime, model = m$model, actual = test_h$Global_active_power,
    point_forecast = pred, lo_80 = NA, hi_80 = NA, lo_95 = NA, hi_95 = NA
  ), fit = fit_rf)
}

if (requireNamespace("xgboost", quietly = TRUE)) {
  cat("  XGBoost...\n")
  mm_tr <- model.matrix(form, data = train_h)[, -1]
  mm_te <- model.matrix(form, data = test_h)[, -1]
  dtr <- xgboost::xgb.DMatrix(mm_tr, label = train_h$Global_active_power)
  dte <- xgboost::xgb.DMatrix(mm_te, label = test_h$Global_active_power)
  t0 <- proc.time()[3]
  fit_xgb <- xgboost::xgb.train(
    params = list(objective = "reg:squarederror", max_depth = 6, eta = 0.08,
                  subsample = 0.8, colsample_bytree = 0.8),
    data = dtr, nrounds = 200, verbose = 0
  )
  pred <- predict(fit_xgb, dte)
  elapsed <- proc.time()[3] - t0
  m <- forecast_metrics(test_h$Global_active_power, pred)
  m$model <- "XGBoost"; m$runtime_sec <- round(elapsed, 2); m$grain <- "hourly"; m$horizon <- "7-day holdout"
  imp <- xgboost::xgb.importance(model = fit_xgb)
  write_table(imp, "xgb_feature_importance.csv")
  results$xgb <- list(metrics = m, fc = data.frame(
    Datetime = test_h$Datetime, model = m$model, actual = test_h$Global_active_power,
    point_forecast = pred, lo_80 = NA, hi_80 = NA, lo_95 = NA, hi_95 = NA
  ), fit = fit_xgb, importance = imp)
}

# Ensemble of snaive + lm + (xgb or rf)
ens_parts <- list(snaive_h = as.numeric(snaive_h), lm = as.numeric(pred_lm))
if (!is.null(results$xgb)) ens_parts$xgb <- results$xgb$fc$point_forecast
if (!is.null(results$rf))  ens_parts$rf  <- results$rf$fc$point_forecast
ens <- rowMeans(as.data.frame(ens_parts), na.rm = TRUE)
m_ens <- forecast_metrics(test_h$Global_active_power, ens)
m_ens$model <- "Ensemble_mean"; m_ens$runtime_sec <- 0; m_ens$grain <- "hourly"; m_ens$horizon <- "7-day holdout"
results$ens <- list(metrics = m_ens, fc = data.frame(
  Datetime = test_h$Datetime, model = m_ens$model, actual = test_h$Global_active_power,
  point_forecast = ens, lo_80 = NA, hi_80 = NA, lo_95 = NA, hi_95 = NA
))

metrics <- dplyr::bind_rows(lapply(results, function(z) z$metrics)) %>%
  dplyr::arrange(grain, RMSE)
print(metrics)
write_table(metrics, "model_comparison.csv")

fc_all <- dplyr::bind_rows(lapply(results, function(z) z$fc))
write.csv(fc_all, file.path(PATHS$forecasts, "forecast_all_models.csv"), row.names = FALSE)

# Canonical forecast_output.csv = best hourly model by RMSE
hourly_metrics <- metrics %>% filter(grain == "hourly")
best_name <- hourly_metrics$model[which.min(hourly_metrics$RMSE)]
best_fc <- fc_all %>% filter(model == best_name)
write.csv(best_fc, file.path(PATHS$forecasts, "forecast_output.csv"), row.names = FALSE)

saveRDS(results, file.path(PATHS$models, "fitted_models.rds"))
saveRDS(list(train_h = train_h, test_h = test_h, form = form, best_name = best_name),
        file.path(PATHS$models, "model_split.rds"))

headline <- metrics %>% filter(grain == "hourly")
cat("\nHEADLINE (hourly 7-day holdout):\n")
print(headline %>% select(model, RMSE, MAE, MAPE, MASE, R2, runtime_sec))
cat("Best hourly model:", best_name, "\n")
cat("Saved outputs/forecasts/model_comparison.csv and forecast_output.csv\n")
