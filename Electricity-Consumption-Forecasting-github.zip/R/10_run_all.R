# 10_run_all.R — execute the pipeline in order
# From the project root in RStudio: source("R/10_run_all.R")

step <- function(rel) {
  path <- if (file.exists(rel)) rel else file.path("R", basename(rel))
  if (!file.exists(path)) path <- file.path("R", rel)
  if (!file.exists(path)) stop("Missing ", rel, " (cwd = ", getwd(), ")")
  cat("\n>>>", path, "\n")
  sys.source(path, envir = globalenv())
}

step("00_setup.R")
step("00_download.R")
step("01_load.R")
step("02_clean.R")
step("03_features.R")
step("04_eda.R")
step("05_models.R")
step("06_evaluate.R")
step("07_anomaly.R")
step("08_cluster.R")
step("09_cost.R")

cat("\nPipeline finished.\n")
cat("Dashboard: shiny::runApp('app')\n")
cat("Report:    rmarkdown::render('report/report.Rmd')\n")
cat("Slides:    rmarkdown::render('report/slides.Rmd')\n")
