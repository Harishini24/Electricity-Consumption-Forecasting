# 02_clean.R — gaps, interpolation, rest-of-house, multi-granularity

if (file.exists("00_utils.R")) source("00_utils.R") else source("R/00_utils.R")
ensure_project_dirs()
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(lubridate)
  library(data.table)
})

message_header("02  Cleaning, gaps, aggregation")

loaded_path <- file.path(PATHS$processed, "df_loaded.rds")
if (!file.exists(loaded_path)) stop("Run 01_load.R first.")

df <- as.data.frame(readRDS(loaded_path))

# UCI note: rest-of-house Wh per minute =
# Global_active_power * 1000/60 - sub1 - sub2 - sub3
df <- df %>%
  mutate(
    energy_wh = Global_active_power * 1000 / 60,
    Rest_of_house = energy_wh - Sub_metering_1 - Sub_metering_2 - Sub_metering_3,
    Rest_of_house = pmax(Rest_of_house, 0),
    outlier_flag = Global_active_power < 0 | Global_active_power > 12 |
      Voltage < 200 | Voltage > 260
  )

n_out <- sum(df$outlier_flag, na.rm = TRUE)
cat(sprintf("Physical/statistical outlier flags: %s (kept, not dropped).\n", format(n_out, big.mark = ",")))

# Complete minute index (UCI says all calendar timestamps are present, but we still pad)
if (requireNamespace("padr", quietly = TRUE)) {
  df <- padr::pad(df, interval = "min", by = "Datetime")
} else {
  full_idx <- data.frame(Datetime = seq(min(df$Datetime, na.rm = TRUE),
                                       max(df$Datetime, na.rm = TRUE), by = "min"))
  df <- full_idx %>% left_join(df, by = "Datetime")
}

# Gap log at minute resolution
na_rle <- rle(is.na(df$Global_active_power))
if (any(na_rle$values)) {
  ends <- cumsum(na_rle$lengths)
  starts <- ends - na_rle$lengths + 1
  gap_df <- data.frame(
    gap_id = seq_along(starts),
    gap_start = df$Datetime[starts],
    gap_end = df$Datetime[ends],
    duration_minutes = na_rle$lengths,
    duration_hours = round(na_rle$lengths / 60, 2),
    is_gap = na_rle$values
  ) %>% filter(is_gap) %>% select(-is_gap)
  write_table(gap_df, "excluded_periods.csv")
  cat(sprintf("Logged %d gap periods. Longest = %.2f hours (%s to %s).\n",
              nrow(gap_df), max(gap_df$duration_hours),
              gap_df$gap_start[which.max(gap_df$duration_hours)],
              gap_df$gap_end[which.max(gap_df$duration_hours)]))
}

# Interpolate ONLY short gaps (<= 3 hours = 180 minutes). Long gaps stay NA
# and are excluded from training windows later.
interp_vec <- function(x, maxgap) {
  if (requireNamespace("imputeTS", quietly = TRUE)) {
    return(imputeTS::na_interpolation(x, option = "linear", maxgap = maxgap))
  }
  zoo::na.approx(x, maxgap = maxgap, na.rm = FALSE)
}

num_cols <- c("Global_active_power", "Global_reactive_power", "Voltage",
              "Global_intensity", "Sub_metering_1", "Sub_metering_2",
              "Sub_metering_3", "energy_wh", "Rest_of_house")
for (cl in num_cols) {
  if (cl %in% names(df)) df[[cl]] <- interp_vec(df[[cl]], maxgap = 180)
}

df$Global_active_power <- pmax(df$Global_active_power, 0)

# ---- multi-granularity aggregation ----
agg_power <- function(data, unit) {
  data %>%
    mutate(Datetime = floor_date(Datetime, unit)) %>%
    group_by(Datetime) %>%
    summarise(
      n_minutes = n(),
      n_obs = sum(!is.na(Global_active_power)),
      Global_active_power = mean(Global_active_power, na.rm = TRUE),
      Global_reactive_power = mean(Global_reactive_power, na.rm = TRUE),
      Voltage = mean(Voltage, na.rm = TRUE),
      Global_intensity = mean(Global_intensity, na.rm = TRUE),
      kWh = sum(energy_wh, na.rm = TRUE) / 1000,
      Sub_metering_1 = sum(Sub_metering_1, na.rm = TRUE),
      Sub_metering_2 = sum(Sub_metering_2, na.rm = TRUE),
      Sub_metering_3 = sum(Sub_metering_3, na.rm = TRUE),
      Rest_of_house = sum(Rest_of_house, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      coverage = n_obs / n_minutes,
      Global_active_power = ifelse(is.nan(Global_active_power), NA_real_, Global_active_power)
    )
}

df_15min  <- agg_power(df, "15 minutes")
df_hourly <- agg_power(df, "hour")
df_daily  <- agg_power(df, "day")
df_weekly <- agg_power(df, "week")
df_monthly <- agg_power(df, "month")

# Fill hourly gaps so the index is regular; keep long-gap NAs
if (requireNamespace("tsibble", quietly = TRUE)) {
  df_hourly <- df_hourly %>%
    tsibble::as_tsibble(index = Datetime) %>%
    tsibble::fill_gaps() %>%
    as.data.frame()
} else {
  full_h <- data.frame(Datetime = seq(min(df_hourly$Datetime), max(df_hourly$Datetime), by = "hour"))
  df_hourly <- full_h %>% left_join(df_hourly, by = "Datetime")
}

# Hourly interpolation of short holes only (<= 3 hours)
for (cl in c("Global_active_power", "kWh", "Voltage", "Sub_metering_1",
             "Sub_metering_2", "Sub_metering_3", "Rest_of_house")) {
  if (cl %in% names(df_hourly)) df_hourly[[cl]] <- interp_vec(df_hourly[[cl]], maxgap = 3)
}

# Minute-level object is ~2M rows; do not persist it (hourly+ is the modelling grain).
saveRDS(df_15min,   file.path(PATHS$processed, "df_15min.rds"))
saveRDS(df_hourly,  file.path(PATHS$processed, "df_hourly.rds"))
saveRDS(df_daily,   file.path(PATHS$processed, "df_daily.rds"))
saveRDS(df_weekly,  file.path(PATHS$processed, "df_weekly.rds"))
saveRDS(df_monthly, file.path(PATHS$processed, "df_monthly.rds"))

gran <- data.frame(
  grain = c("minute", "15min", "hourly", "daily", "weekly", "monthly"),
  n = c(nrow(df), nrow(df_15min), nrow(df_hourly), nrow(df_daily), nrow(df_weekly), nrow(df_monthly))
)
write_table(gran, "granularity_counts.csv")
cat("Aggregation complete:\n")
print(gran)
cat("Note: minute RDS is large. Modelling uses hourly/daily.\n")
