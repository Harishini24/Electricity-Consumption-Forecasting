# 10_simulator.R
# Prescriptive Intelligence: What-If Energy Optimization Simulator

library(dplyr)

cat("Starting What-If Simulator calculations...\n")

if(file.exists("../data/processed/df_hourly.rds")) {
  df <- readRDS("../data/processed/df_hourly.rds")
  
  # Simulate a Peak-Reduction Scenario
  # Identify Peak Hours (18:00 - 22:00)
  # Calculate baseline consumption during these hours
  
  df_sim <- df %>%
    mutate(
      Hour = lubridate::hour(Datetime),
      is_peak = Hour >= 18 & Hour <= 22,
      # Scenario: Reduce peak consumption by 15%
      Optimized_Power = ifelse(is_peak, Global_active_power * 0.85, Global_active_power)
    )
    
  baseline_total <- sum(df_sim$Global_active_power, na.rm = TRUE)
  optimized_total <- sum(df_sim$Optimized_Power, na.rm = TRUE)
  
  cat(sprintf("Baseline Total Consumption: %.2f kWh\n", baseline_total))
  cat(sprintf("Optimized Total Consumption: %.2f kWh\n", optimized_total))
  cat(sprintf("Total Energy Saved: %.2f kWh\n", baseline_total - optimized_total))
  
  # Note: The actual interactive simulation is handled in the Shiny app (app/app.R)
  
} else {
  cat("df_hourly.rds not found. Run 02_clean.R first.\n")
}
